# agent-cache

Per-endpoint agent memory: `<Module>/<METHOD>__<path-slug>.cache.yaml` — spec signature, artifact paths, test-case inventory, append-only action history with token accounting. Written and read by all three agents; schema in `../agents/shared/AGENT_CACHE_SPEC.md`. Committed to the repo so every collaborator's agents share the same history. Do not edit by hand.
