# agent-reports

One presentation-quality Markdown report per agent run: `<YYYY-MM-DD>__<agent>__<module>.md` — executive summary, coverage bars, findings/artifacts, token economics (created vs reused-from-cache), next steps. Format in `../agents/shared/AGENT_REPORT_SPEC.md`. Reports are never overwritten.
