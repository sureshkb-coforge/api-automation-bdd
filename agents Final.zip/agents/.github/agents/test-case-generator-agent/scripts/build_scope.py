"""Build scripts/approved_scope.json - the handoff contract between the
swagger-endpoint-sync analyzer and the swagger-test-case-generator-agent agent.

Runs structure + coverage checks directly (no intermediate files) and keeps
only the gaps matching the approved priorities. Also computes nextTcId from
the highest existing TC id, and guesses each endpoint's module from the
matched artifact paths (testdata/<Module>/ or features/<Module>/), falling
back to the first swagger path segment.

Usage (after the user approves the scope):
  python build_scope.py --swagger-file api.json --project-root .
      --priority P0,P1 [--spec-source swagger|ado|postman]
      [--out scripts/approved_scope.json]

Exit code 0 always (an empty scope is valid - it means nothing to generate).
"""
import argparse
import os

# --- path shim: make shared/ and sibling agents' scripts importable ---
import os as _os, sys as _sys
_AGENTS = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
for _d in ("shared",
           _os.path.join("framework-standards-agent", "scripts"),
           _os.path.join("structure-generator-agent", "scripts"),
           _os.path.join("test-case-generator-agent", "scripts")):
    _p = _os.path.join(_AGENTS, _d)
    if _p not in _sys.path:
        _sys.path.insert(0, _p)
# ----------------------------------------------------------------------

from fw_common import (extract_endpoints, fuzzy_match, load_swagger,
                       name_hints, next_tc_id, scan_project, write_json)
from swagger_coverage import coverage_for
from validate_structure import COLS, check_endpoint


def guess_module(ep, inv):
    hints = name_hints(ep)
    for pool, marker in ((inv["yaml_files"], "testdata/"),
                         (inv["feature_files"], "features/")):
        for f in fuzzy_match(pool, hints):
            if marker in f:
                seg = f.split(marker, 1)[1].split("/")[0]
                if "." not in seg:
                    return seg
    segs = [s for s in ep["path"].split("/") if s and not s.startswith("{")]
    return (segs[0][:1].upper() + segs[0][1:]) if segs else "Unknown"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--swagger-file", required=True)
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--priority", default="P0,P1",
                    help="comma-separated priorities to include (default P0,P1)")
    ap.add_argument("--spec-source", default="swagger",
                    choices=["swagger", "ado", "postman"])
    ap.add_argument("--out", default=None,
                    help="default: <project-root>/scripts/approved_scope.json")
    args = ap.parse_args()

    wanted = {p.strip().upper() for p in args.priority.split(",") if p.strip()}
    out = args.out or os.path.join(args.project_root, "scripts",
                                   "approved_scope.json")

    eps = extract_endpoints(load_swagger(args.swagger_file))
    inv = scan_project(args.project_root)

    scope_eps = []
    for ep in eps:
        res, _ = check_endpoint(ep, inv)
        missing_artifacts = [c for c in COLS if res[c] != "OK"]
        cov = coverage_for(ep, inv)
        missing_cases = [m for m in cov["missing"]
                         if m["priority"] in wanted]
        if not missing_artifacts and not missing_cases:
            continue
        scope_eps.append({
            "path": ep["path"],
            "method": ep["method"],
            "module": guess_module(ep, inv),
            "status": "NEW" if len(missing_artifacts) == len(COLS)
                      else "UPDATED",
            "missingArtifacts": missing_artifacts,
            "missingCases": [{"area": m["area"], "scenario": m["case"],
                              "priority": m["priority"]}
                             for m in missing_cases],
        })

    write_json(out, {
        "specPath": os.path.abspath(args.swagger_file).replace("\\", "/"),
        "specSource": args.spec_source,
        "approvedPriorities": sorted(wanted),
        "endpoints": scope_eps,
        "nextTcId": next_tc_id(inv),
    })
    total_cases = sum(len(e["missingCases"]) for e in scope_eps)
    print("Scope: %d endpoint(s), %d test case(s) to generate, nextTcId=%d"
          % (len(scope_eps), total_cases, next_tc_id(inv)))


if __name__ == "__main__":
    main()
