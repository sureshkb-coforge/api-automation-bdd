"""excel_to_yaml.py — legacy Excel/CSV test data -> framework YAML converter.

Converts spreadsheet test data into env-nested TC_XXXXX YAML blocks per
API_TEST_STANDARDS.md. Expected columns (header row, case-insensitive):
  TC_ID | Description | Environment | StatusCode | HeaderType | <payload fields...>
Every remaining column becomes a requestPayload key. Rows sharing a TC_ID
with different Environment values merge into one env-nested block.

Usage:
  python excel_to_yaml.py --input data.xlsx --sheet Sheet1 --out testdata/Alert/CreateAlert.yaml
  python excel_to_yaml.py --input data.csv --out testdata/Alert/CreateAlert.yaml

.xlsx needs openpyxl (pip install openpyxl); .csv is stdlib-only.
"""
import argparse
import csv
import os
import sys

KNOWN = {"tc_id", "description", "environment", "statuscode", "headertype"}


def read_rows(path, sheet):
    if path.lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig") as fh:
            return [list(r) for r in csv.reader(fh)]
    try:
        import openpyxl
    except ImportError:
        sys.exit("ERROR: reading .xlsx needs openpyxl (pip install openpyxl), "
                 "or export the sheet to CSV and pass that instead.")
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb[sheet] if sheet else wb.active
    return [["" if c is None else str(c) for c in row]
            for row in ws.iter_rows(values_only=True)]


def convert(rows):
    header = [str(h or "").strip() for h in rows[0]]
    idx = {h.lower().replace(" ", "_"): i for i, h in enumerate(header)}
    for req in ("tc_id", "statuscode"):
        if req not in idx:
            sys.exit("ERROR: required column '%s' not found in header %s" % (req, header))
    payload_cols = [(h, i) for i, h in enumerate(header)
                    if h and h.lower().replace(" ", "_") not in KNOWN]

    cases = {}  # tc_id -> {env -> block}
    for row in rows[1:]:
        if not any(str(c).strip() for c in row):
            continue
        get = lambda k: str(row[idx[k]]).strip() if k in idx and idx[k] < len(row) else ""
        tc = get("tc_id")
        if not tc.upper().startswith("TC"):
            continue
        tc = "TC_" + "".join(ch for ch in tc if ch.isdigit())
        env = (get("environment") or "QA").upper()
        block = {"statusCode": get("statuscode") or "200"}
        if get("headertype"):
            block["headerType"] = get("headertype")
        if get("description"):
            block["_description"] = get("description")
        payload = {h: str(row[i]).strip() for h, i in payload_cols
                   if i < len(row) and str(row[i]).strip() != ""}
        if payload:
            block["requestPayload"] = payload
        cases.setdefault(tc, {})[env] = block
    return cases


def emit_yaml(cases):
    out = []
    for tc in sorted(cases):
        out.append("%s:" % tc)
        for env in sorted(cases[tc]):
            block = cases[tc][env]
            desc = block.pop("_description", None)
            if desc:
                out.append("  # %s" % desc)
            out.append("  %s:" % env)
            out.append("    statusCode: %s" % block["statusCode"])
            if "headerType" in block:
                out.append("    headerType: %s" % block["headerType"])
            if "requestPayload" in block:
                out.append("    requestPayload:")
                for k, v in block["requestPayload"].items():
                    out.append("      %s: %s" % (k, v))
        out.append("")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True, help=".xlsx or .csv test data")
    ap.add_argument("--sheet", help="worksheet name (.xlsx only; default: active)")
    ap.add_argument("--out", required=True, help="target YAML path")
    args = ap.parse_args()

    rows = read_rows(args.input, args.sheet)
    if len(rows) < 2:
        sys.exit("ERROR: no data rows found in %s" % args.input)
    cases = convert(rows)
    text = emit_yaml(cases)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write(text)
    print("Converted %d test cases -> %s (%d bytes)"
          % (len(cases), args.out, len(text)))


if __name__ == "__main__":
    main()
