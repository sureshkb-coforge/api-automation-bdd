"""Compare Swagger/OpenAPI endpoints against existing feature/YAML test cases
and report present vs missing scenarios per the API test standards.

Expected automatable cases per endpoint (derived from the spec ONLY):
  - 1 positive (documented 2xx)                       [area 1,  P0]
  - 1 negative per documented 4xx/5xx response code   [area 11, P0 for
    401/403, P1 otherwise]
  - 1 missing-required-field case per required field  [area 2,  P0]
  - noHeader + invalidHeader when endpoint is secured [area 4,  P0]

Present cases are detected by linking feature TC IDs to YAML statusCode
values, plus scenario-name keywords for required-field cases.

Usage:
  python swagger_coverage.py --swagger-file api.json --project-root .
      [--json coverage.json]

Exit code 0 = 100% coverage of expected automatable cases, 1 otherwise.
"""
import argparse
import sys

# --- path shim: make shared/ and sibling agents' scripts importable ---
import os as _os, sys as _sys
_AGENTS = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
for _d in ("shared",
           _os.path.join("framework-standards-agent", "scripts"),
           _os.path.join("structure-generator-agent", "scripts"),
           _os.path.join("test-case-generator-agent", "scripts")):
    _p = _os.path.join(_AGENTS, _d)
    if _p not in _sys.path:
        _sys.path.insert(0, _p)
# ----------------------------------------------------------------------

from fw_common import (extract_endpoints, fuzzy_match, load_swagger,
                       name_hints, norm, print_table, scan_project,
                       write_json)


def coverage_for(ep, inv):
    """Coverage result for one endpoint:
    {scenarios, present, expected, missing:[{case, area, priority}]}"""
    hints = name_hints(ep)
    feats = fuzzy_match(inv["feature_files"], hints)
    yamls = fuzzy_match(inv["yaml_files"], hints)
    scen = [s for s in inv["scenarios"] if s[0] in feats]

    tc_status = {key: codes for (f, key), codes in inv["yaml_status"].items()
                 if f in yamls}
    covered_codes = set()
    for s in scen:
        covered_codes |= tc_status.get(s[1], set())

    covered_fields = set()
    for s in scen:
        n = norm(s[2])
        for field in ep["required_fields"]:
            if norm(field) in n and any(
                    k in n for k in ("missing", "without", "null", "empty",
                                     "remove", "blank")):
                covered_fields.add(field)

    expected, present, missing = 0, 0, []

    def need(case, area, priority, have):
        nonlocal expected, present
        expected += 1
        if have:
            present += 1
        else:
            missing.append({"case": case, "area": area, "priority": priority})

    pos = [c for c in ep["responses"] if c.startswith("2")]
    need("positive %s" % "/".join(pos or ["2xx"]), 1, "P0",
         any(c in covered_codes for c in pos))
    for c in (c for c in ep["responses"] if c[:1] in "45"):
        need("negative %s" % c, 11,
             "P0" if c in ("401", "403") else "P1", c in covered_codes)
    for f in ep["required_fields"]:
        need("missing-field '%s'" % f, 2, "P0", f in covered_fields)
    if ep["secured"]:
        for hdr in ("noHeader", "invalidHeader"):
            named = any(norm(hdr) in norm(s[2]) for s in scen)
            need("auth %s (401)" % hdr, 4, "P0",
                 named or "401" in covered_codes)

    return {"scenarios": len(scen), "present": present,
            "expected": expected, "missing": missing}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--swagger-file", required=True)
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--json", dest="json_out", default=None,
                    help="also write results as JSON to this path")
    args = ap.parse_args()

    eps = extract_endpoints(load_swagger(args.swagger_file))
    inv = scan_project(args.project_root)

    rows, gaps, results, tot_exp, tot_have = [], [], [], 0, 0
    for ep in eps:
        cov = coverage_for(ep, inv)
        pct = 100 * cov["present"] // cov["expected"] if cov["expected"] else 100
        tot_exp += cov["expected"]
        tot_have += cov["present"]
        rows.append([ep["method"], ep["path"], str(cov["scenarios"]),
                     "%d/%d" % (cov["present"], cov["expected"]),
                     "%d%%" % pct, str(len(cov["missing"]))])
        gaps += ["%s %s: %s [%s]" % (ep["method"], ep["path"],
                                     m["case"], m["priority"])
                 for m in cov["missing"]]
        results.append(dict(cov, method=ep["method"], path=ep["path"],
                            coverage_pct=pct))

    print_table(["Method", "Path", "Scenarios", "Present/Expected",
                 "Coverage", "Missing"], rows)
    if gaps:
        print("\nMissing scenarios (per standards):")
        for g in gaps:
            print("  - " + g)
    overall = 100 * tot_have // tot_exp if tot_exp else 100
    print("\nOverall coverage: %d%% (%d/%d expected automatable cases). "
          "Business-rule, DB, performance and concurrency cases are not "
          "spec-derivable - assess those manually per API_TEST_STANDARDS.md."
          % (overall, tot_have, tot_exp))
    if args.json_out:
        write_json(args.json_out, {
            "endpoints": results,
            "overall": {"coverage_pct": overall, "present": tot_have,
                        "expected": tot_exp}})
    sys.exit(0 if tot_have == tot_exp else 1)


if __name__ == "__main__":
    main()
