# test-case-generator-agent — Version History

**Current version: 3.0.1**

## 3.0.1 — 2026-07-13
- PATCH: Agent definition moved to `.github/agents/test-case-generator-agent.agent.md` (top level — the only location Copilot discovers agents from); scripts and this version file stay in the agent's folder.

Covers `test-case-generator-agent.agent.md`, `scripts/swagger_coverage.py`, `scripts/build_scope.py`, `scripts/excel_to_yaml.py`. See `../shared/VERSIONING.md`.

## 3.0.0 — 2026-07-13
- Initial release of Agent 3 per "API Automation — AI Framework v3.0": Test Case Generator Agent — coverage analysis per API_TEST_STANDARDS.md (12 areas, P0–P3, approved scope), then generates Cucumber feature files + env-nested TC_XXXXX YAML test data (artifacts 6–7); enhances existing tests, never regenerates or renumbers.
- `scripts/excel_to_yaml.py` — legacy Excel/CSV test data → env-nested YAML conversion.
- Mandatory user-input gates: T0 spec (Swagger/ADO/Postman) + prerequisites intake, T1 scope approval, T3 accept/rework decision.
- Test failure → ask user for test data (mandatory): failing or spec-underivable data values are requested from the user per TC, never invented; provided values merge into the endpoint YAML and the request is logged in cache + report.
- Per-endpoint cache, impressive report file, token accounting created vs reused-from-cache.
