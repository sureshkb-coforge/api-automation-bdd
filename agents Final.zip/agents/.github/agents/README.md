# Art.Api.Automation — Copilot AI Agents (v3.0)

Three GitHub Copilot agents implementing the "API Automation — AI-Infused Framework v3.0" design. Input: a Swagger/OpenAPI file, ADO-hosted spec, or Postman collection. Output: a standards-compliant, CI/CD-ready automated test suite — with a mandatory user decision at every gate.

```
.github/
├── agents/
│   ├── framework-standards-agent.agent.md   Agent 1 — rulebook enforcer (validates, gates)
│   ├── structure-generator-agent.agent.md   Agent 2 — SPS scaffolder (artifacts 1–5)
│   ├── test-case-generator-agent.agent.md   Agent 3 — coverage + tests (artifacts 6–7)
│   │     (agent definitions live at this top level — Copilot only discovers them here)
│   ├── framework-standards-agent/
│   │   ├── framework-standards-agent.version.md
│   │   └── scripts/ validate_structure.py · detect_duplicates.py
│   ├── structure-generator-agent/
│   │   ├── structure-generator-agent.version.md
│   │   └── scripts/ sps_plan.py
│   ├── test-case-generator-agent/
│   │   ├── test-case-generator-agent.version.md
│   │   └── scripts/ swagger_coverage.py · build_scope.py · excel_to_yaml.py
│   └── shared/  fw_common.py · AGENT_CACHE_SPEC.md · AGENT_REPORT_SPEC.md · VERSIONING.md
├── prompts/
│   └── api-automation-pipeline.prompt.md   (runs 1 → 2 → 3, gated)
├── agent-cache/                one cache file per endpoint, per module folder (see AGENT_CACHE_SPEC.md)
└── agent-reports/              one impressive Markdown report per run (see AGENT_REPORT_SPEC.md)
```

## Pipeline

| # | Agent | Does | Mandatory user gates |
|---|---|---|---|
| 1 | framework-standards-agent | Validates framework structure, conventions, duplicates against the spec | G0 spec+scope intake · G3 fix/proceed/stop |
| 2 | structure-generator-agent | Scaffolds config keys, Module/Endpoint enums, DTO, Service, StepDef from the SPS plan | S0 module+envs · S1 plan approval · S3 handoff |
| 3 | test-case-generator-agent | Coverage analysis (P0–P3), then feature files + env-nested YAML test data; Excel→YAML | T0 intake · T1 scope approval · T3 accept/rework |

## Non-negotiables (all agents)

- **Cache first** — read `.github/agent-cache/<Module>/<METHOD>__<path-slug>.cache.yaml` before touching an endpoint; write back after, append-only history.
- **Token accounting** — every console summary and report file shows tokens **created** (spent this run) vs **reused** (saved via cache) with savings %.
- **Impressive report file** — every run writes `.github/agent-reports/<date>__<agent>__<module>.md` and prints its path as the last console line.
- **User input at every phase** — each phase starts by confirming inputs (the spec — Swagger/ADO/Postman — is always asked for, never assumed) and ends with an explicit user decision.
- **Test failure → ask for test data** — a failing or spec-underivable test case triggers a mandatory user request for the real data (endpoint, TC id, env, fields); values are never invented.
- **Clean, compact console output** — tables and counts only, best answer in the fewest tokens; full detail lives in the report file.
- **Versioning** — each agent has its own semver + `.version.md` changelog; every enhancement bumps it (see `shared/VERSIONING.md`).
