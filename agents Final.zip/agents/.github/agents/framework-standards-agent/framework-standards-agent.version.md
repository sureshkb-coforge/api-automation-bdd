# framework-standards-agent — Version History

**Current version: 3.1.0**

## 3.1.0 — 2026-07-13
- MINOR: Pipeline prompt — explicit START BEHAVIOR: on invocation the first reply is ONLY the input questionnaire (spec source, module scope, environments, optional Excel/CSV); nothing runs until the user answers.
- MINOR: Pipeline prompt — 9 STRICT GUARDRAILS binding all agents: no input → no action; spec is the only source of truth; nothing written before approval; surgical changes only; failed test data comes from the user; mandatory validation; honest cache/token numbers; clean console; stay in role.
- MINOR: Pipeline prompt — consolidated FINAL OUTPUT block (`=== PIPELINE COMPLETE ===`) closing the run with totals across all 3 agents and the 3 report paths.

Covers `framework-standards-agent.agent.md`, `scripts/validate_structure.py`, `scripts/detect_duplicates.py`, and `.github/prompts/api-automation-pipeline.prompt.md`. See `../shared/VERSIONING.md`.

## 3.0.1 — 2026-07-13
- PATCH: Pipeline prompt frontmatter — replaced deprecated `mode: agent` with `agent: framework-standards-agent` so `/api-automation-pipeline` launches under Agent 1.
- PATCH: Agent definition moved to `.github/agents/framework-standards-agent.agent.md` (top level — the only location Copilot discovers agents from); scripts and this version file stay in the agent's folder.

## 3.0.0 — 2026-07-13
- Initial release of Agent 1 per "API Automation — AI Framework v3.0": Framework Standards Agent — rulebook enforcer. Validates structure (7 artifacts per endpoint), coding conventions, DTO/Service/StepDef/Feature patterns, duplicates; gates the pipeline with a fix / proceed / stop decision.
- Mandatory user-input gates at every phase (G0 spec + module intake — Swagger/ADO/Postman required; G3 verdict decision).
- Per-endpoint cache (`../shared/AGENT_CACHE_SPEC.md`), impressive report file (`../shared/AGENT_REPORT_SPEC.md`), token accounting created vs reused-from-cache.
