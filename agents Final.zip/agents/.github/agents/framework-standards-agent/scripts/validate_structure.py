"""Validate that every endpoint in a Swagger/OpenAPI spec has all 7 required
Art.Api.Automation framework artifacts, in the correct folders:

  1. config property key (present in EVERY config-<ENV>.properties)
  2. <Module>Endpoint enum constant wrapping that key
  3. <Endpoint>Dto.java with Request(/Body)/Projection inner classes
  4. <Module>Service method
  5. <Endpoint>StepDef.java
  6. .feature file with 3-step scenarios
  7. testdata YAML whose TC keys match the feature's TC IDs

Also enforces global framework rules (feature @Regression tag, YAML env
nesting, valid headerType values, Module enum <-> base-urls.yaml parity) and
classifies endpoints NEW/UPDATED/UNCHANGED against a saved spec snapshot.

Usage:
  python validate_structure.py --swagger-file api.json --project-root .
      [--save-snapshot] [--snapshot-file scripts/.last_spec.json]
      [--orphans] [--json out.json]

--orphans lists path-like config keys with no endpoint in THIS spec; only
meaningful when the spec covers the whole module, so it is opt-in.

Exit code 0 = all endpoints complete and no rule violations, 1 otherwise.
"""
import argparse
import os
import sys

# --- path shim: make shared/ and sibling agents' scripts importable ---
import os as _os, sys as _sys
_AGENTS = _os.path.dirname(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
for _d in ("shared",
           _os.path.join("framework-standards-agent", "scripts"),
           _os.path.join("structure-generator-agent", "scripts"),
           _os.path.join("test-case-generator-agent", "scripts")):
    _p = _os.path.join(_AGENTS, _d)
    if _p not in _sys.path:
        _sys.path.insert(0, _p)
# ----------------------------------------------------------------------

from fw_common import (classify, ep_key, extract_endpoints,
                       framework_rule_violations, fuzzy_match, load_snapshot,
                       load_swagger, name_hints, norm, print_table,
                       save_snapshot, scan_project, write_json)

OK, MISS = "OK", "MISSING"
COLS = ["config", "enum", "dto", "service", "stepdef", "feature", "yaml"]


def check_endpoint(ep, inv):
    hints = name_hints(ep)
    res, notes = {}, []
    swagger_path = norm(ep["path"])

    # 1. config key: a property whose VALUE matches the swagger path
    cfg_key, present_in = None, []
    for f, props in inv["config_files"].items():
        for k, v in props.items():
            nv = norm(v.split("?")[0])
            if nv and (nv == swagger_path or swagger_path.startswith(nv)):
                cfg_key = cfg_key or k
                present_in.append(f)
                break
    if cfg_key:
        missing_env = [f for f in inv["config_files"] if f not in present_in]
        res["config"] = OK if not missing_env else "PARTIAL"
        for f in missing_env:
            notes.append("config key '%s' missing in %s" % (cfg_key, f))
    else:
        res["config"] = MISS

    # 2. enum constant wrapping that config key (fallback: fuzzy name match)
    enums = [c for f, c, key in inv["enum_constants"]
             if (cfg_key and key == cfg_key) or norm(c) in hints
             or any(h in norm(c) for h in hints)]
    res["enum"] = OK if enums else MISS

    # 3. DTO with correct inner-class shape
    res["dto"] = MISS
    for cls in fuzzy_match(inv["dtos"], hints):
        d = inv["dtos"][cls]
        shape_ok = d["projection"] and (d["request"] or not ep["has_body"])
        res["dto"] = OK if shape_ok else "BAD-SHAPE"
        if not shape_ok:
            notes.append("%s: needs %s" % (
                d["file"],
                "Projection" if not d["projection"] else "Request"))
        break

    # 4. service method
    res["service"] = OK if fuzzy_match(
        [m for _, m in inv["service_methods"]], hints) else MISS

    # 5. step definition file
    res["stepdef"] = OK if fuzzy_match(inv["stepdef_files"], hints) else MISS

    # 6. feature file + scenario shape
    feats = fuzzy_match(inv["feature_files"], hints)
    scen = [s for s in inv["scenarios"] if s[0] in feats]
    if not feats:
        res["feature"] = MISS
    else:
        bad = [s for s in scen if s[3] != 3]
        res["feature"] = OK if scen and not bad else "BAD-SHAPE"
        for s in bad:
            notes.append("%s '%s' has %d steps (must be 3)" %
                         (s[0], s[2][:40], s[3]))
        if not scen:
            notes.append("%s has no scenarios" % feats[0])

    # 7. YAML testdata + TC keys match feature TC IDs
    yamls = fuzzy_match(inv["yaml_files"], hints)
    if not yamls:
        res["yaml"] = MISS
    else:
        keys = {k for f, k in inv["yaml_keys"] if f in yamls}
        tcs = {s[1] for s in scen if s[1]}
        res["yaml"] = OK if tcs and tcs <= keys else ("PARTIAL" if keys else "EMPTY")
        for tc in sorted(tcs - keys):
            notes.append("%s missing YAML key for %s" % (yamls[0], tc))
    return res, notes


def find_orphans(eps, inv):
    """Path-like config values with no matching endpoint in this spec."""
    spec_paths = [norm(e["path"]) for e in eps]
    orphans = []
    for f, props in sorted(inv["config_files"].items()):
        for k, v in sorted(props.items()):
            if not v.startswith("/"):
                continue  # baseURL/apiKey/etc. are not endpoint paths
            nv = norm(v.split("?")[0])
            if nv and not any(sp == nv or sp.startswith(nv)
                              for sp in spec_paths):
                orphans.append("%s: %s=%s" % (f, k, v))
    return orphans


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--swagger-file", required=True)
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--snapshot-file", default=None,
                    help="default: <project-root>/scripts/.last_spec.json")
    ap.add_argument("--save-snapshot", action="store_true",
                    help="save this spec as the baseline for future diffs")
    ap.add_argument("--orphans", action="store_true",
                    help="report config paths not present in this spec")
    ap.add_argument("--json", dest="json_out", default=None,
                    help="also write results as JSON to this path")
    args = ap.parse_args()

    snap_file = args.snapshot_file or os.path.join(
        args.project_root, "scripts", ".last_spec.json")
    eps = extract_endpoints(load_swagger(args.swagger_file))
    snapshot = load_snapshot(snap_file)
    inv = scan_project(args.project_root)
    if not inv["config_files"]:
        print("WARNING: no config-*.properties found under %s"
              % args.project_root)

    rows, all_notes, results, bad = [], [], [], 0
    for ep in eps:
        res, notes = check_endpoint(ep, inv)
        status = "VALID" if all(res[c] == OK for c in COLS) else "INCOMPLETE"
        bad += status != "VALID"
        cls = classify(ep, snapshot)
        rows.append([ep["method"], ep["path"], cls]
                    + [res[c] for c in COLS] + [status])
        all_notes += ["%s %s: %s" % (ep["method"], ep["path"], n)
                      for n in notes]
        results.append({"method": ep["method"], "path": ep["path"],
                        "classification": cls, "checks": res,
                        "status": status, "notes": notes})

    print_table(["Method", "Path", "Class"] + COLS + ["Status"], rows)

    removed = sorted(set(snapshot or {}) - {ep_key(e) for e in eps})
    if removed:
        print("\nREMOVED (in previous spec snapshot, not in this spec):")
        for r in removed:
            print("  - " + r)

    rules = framework_rule_violations(inv)
    if rules:
        print("\nFramework rule violations:")
        for r in rules:
            print("  - " + r)

    orphans = find_orphans(eps, inv) if args.orphans else []
    if orphans:
        print("\nOrphan config paths (no endpoint in this spec - check "
              "whether the spec covers the whole module before deleting):")
        for o in orphans:
            print("  - " + o)

    if all_notes:
        print("\nDetails:")
        for n in all_notes:
            print("  - " + n)

    print("\n%d/%d endpoints structurally valid, %d rule violation(s)."
          % (len(eps) - bad, len(eps), len(rules)))

    if args.save_snapshot:
        save_snapshot(snap_file, eps)
        print("Snapshot saved: %s" % snap_file)
    if args.json_out:
        write_json(args.json_out, {"endpoints": results, "removed": removed,
                                   "rule_violations": rules,
                                   "orphans": orphans})
    sys.exit(1 if bad or rules else 0)


if __name__ == "__main__":
    main()
