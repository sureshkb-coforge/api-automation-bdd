# Agent Versioning Policy (v3.0 layout)

Agent definitions (`<name>.agent.md`) live at the top of `.github/agents/` — the only location Copilot discovers them from. Each agent additionally owns a folder there holding its scripts and its version file:

| Agent | Definition | Scripts + version file |
|---|---|---|
| framework-standards-agent (Agent 1) | `.github/agents/framework-standards-agent.agent.md` | `.github/agents/framework-standards-agent/` |
| structure-generator-agent (Agent 2) | `.github/agents/structure-generator-agent.agent.md` | `.github/agents/structure-generator-agent/` |
| test-case-generator-agent (Agent 3) | `.github/agents/test-case-generator-agent.agent.md` | `.github/agents/test-case-generator-agent/` |

## Rules

1. **Semantic versioning** (`MAJOR.MINOR.PATCH`):
   - **MAJOR** — breaking workflow change: phases added/removed/reordered, handoff contract changed (cache schema, `approved_scope.json`, SPS plan shape), output format changed incompatibly.
   - **MINOR** — enhancement: new capability, new rule, new/changed script, expanded logic.
   - **PATCH** — fix or clarification with no behavior change.
2. **Every change to an agent's `.agent.md`, its `scripts/*.py`, or a prompt it owns MUST, in the same edit session:**
   - bump `version:` in the agent file's frontmatter, and
   - add a dated changelog entry to the agent's `.version.md` (newest on top).
3. Changes to `shared/` files (`fw_common.py`, `AGENT_CACHE_SPEC.md`, `AGENT_REPORT_SPEC.md`, this file) that alter behavior require a MINOR bump in **every agent that consumes them**, with the entry naming the shared file.
4. The pipeline prompt (`.github/prompts/api-automation-pipeline.prompt.md`) is versioned under framework-standards-agent (it fronts the pipeline).
5. Never rewrite or delete past changelog entries; history is append-only.

## Changelog entry format

```
## <version> — <YYYY-MM-DD>
- <MAJOR|MINOR|PATCH>: <what changed and why, one line per change>
```
