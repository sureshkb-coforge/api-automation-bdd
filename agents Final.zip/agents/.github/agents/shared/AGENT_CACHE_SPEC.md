# Agent Cache Specification (v1 — agents v3.0.0)

The cache is how the agents avoid re-loading framework content on every run. After work completes on an endpoint, the agent records everything it learned/did in one cache file per endpoint. On any later rework, agents consult the endpoint's cache FIRST and only read the real files needed to verify or extend it.

## Location & naming

```
<project-root>/.github/agent-cache/<Module>/<METHOD>__<path-slug>.cache.yaml
```

- `<Module>` — framework module owning the endpoint (matches the `Module` enum, e.g. `Alert`).
- `<path-slug>` — endpoint path lowercased, `/` and `{}` replaced with `_`, e.g. `POST__v1_alerts.cache.yaml`, `GET__v1_alerts__alertid_.cache.yaml`.
- One file per endpoint, one folder per module. Example: alert module → `.github/agent-cache/Alert/POST__v1_alerts.cache.yaml`.

## File schema

```yaml
endpoint:
  method: POST
  path: /v1/alerts
  module: Alert
  configKey: alert.create.path          # key used in config-<ENV>.properties
  endpointEnum: AlertEndpoint.CREATE_ALERT
specSignature: <sha256 of the endpoint's normalized spec fragment>  # from fw_common normalization
artifacts:                              # the 7 artifacts, actual paths
  configProperties: [<one per env>]
  endpointEnum: <path>
  dto: <path>
  service: <path>
  stepDefinition: <path>
  feature: <path>
  testData: <path>
testCases:                              # every TC known for this endpoint
  - id: TC_10021
    title: <short description>
    type: positive|negative
    area: <1-12 per API_TEST_STANDARDS.md>
    status: existing|created|enhanced   # existing = pre-dated the agents
history:                                # APPEND-ONLY, newest LAST — complete action log
  - date: 2026-07-13
    agent: test-case-generator-agent@3.0.0
    action: analyzed|generated|enhanced|repaired
    summary: <one line: what was done and why>
    filesCreated: [<paths>]
    filesModified: [<paths>]
    tokens:
      created: <est. tokens spent on fresh reads/writes this run>
      reused: <est. tokens SAVED by trusting this cache instead of re-reading files>
```

## Rules

1. **Read before work.** Any agent starting work on an endpoint MUST first look for its cache file. Cache HIT with matching `specSignature` → trust `artifacts` + `testCases` (verify cheaply: files exist, one grep for the newest TC id) and skip deep reads. Signature mismatch → endpoint is UPDATED: do a full re-analysis of that endpoint only, then refresh the cache. No file → MISS: full analysis, create the cache after work completes.
2. **Write after work.** Whichever agent finishes work on an endpoint updates its cache file in the same run: refresh `artifacts`/`testCases`/`specSignature`, append ONE `history` entry. Never rewrite or delete prior history entries.
3. **Token accounting.** Every history entry records `created` (tokens actually spent this run, bytes÷4) and `reused` (estimated tokens the cache saved — the size of files NOT re-read because the cache answered). Reports surface both totals.
4. **Enhance, never duplicate.** When rework touches an endpoint with cached `testCases`, enhance the existing TCs / add only missing ones — never regenerate or renumber existing TC ids.
5. **Cache is a hint, files are truth.** If a cheap verification contradicts the cache (artifact missing, TC id absent), treat the endpoint as MISS, re-analyze, and repair the cache — log `action: repaired`.
6. Cache files are committed to the repo (they live under `.github/`) so every collaborator's agents share the same history.
