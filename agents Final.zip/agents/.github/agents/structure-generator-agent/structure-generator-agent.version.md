# structure-generator-agent — Version History

**Current version: 3.0.1**

## 3.0.1 — 2026-07-13
- PATCH: Agent definition moved to `.github/agents/structure-generator-agent.agent.md` (top level — the only location Copilot discovers agents from); scripts and this version file stay in the agent's folder.

Covers `structure-generator-agent.agent.md` and `scripts/sps_plan.py`. See `../shared/VERSIONING.md`.

## 3.0.0 — 2026-07-13
- Initial release of Agent 2 per "API Automation — AI Framework v3.0": Structure Generator Agent — reads the Service Path Structure (SPS) plan and auto-scaffolds artifacts 1–5 (config properties per env, base-urls.yaml + Module enum, Endpoint enum, DTO, Service method, StepDef stub). Zero manual folder creation.
- `scripts/sps_plan.py` — deterministic scaffold plan (artifact paths, config keys, exists-vs-CREATE) so structure is never re-derived from the repo.
- Mandatory user-input gates: S0 module + environments intake, S1 plan approval before any file is written, S3 handoff decision.
- Per-endpoint cache, impressive report file, token accounting created vs reused-from-cache.
