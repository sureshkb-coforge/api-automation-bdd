"""sps_plan.py — Service Path Structure (SPS) planner for structure-generator-agent.

From an API spec + project root, emit the deterministic scaffold plan:
per endpoint, the 7 artifact paths (existing vs to-create), the module
package layout, and config keys — so the agent scaffolds from a plan
instead of re-deriving structure by reading the repo.

Stdlib-only. Usage:
  python sps_plan.py --swagger-file spec.json --project-root . --module Alert [--json plan.json]
"""
import argparse
import glob
import os

# --- path shim: make shared/ and sibling agents' scripts importable ---
import sys as _sys
_AGENTS = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for _d in ("shared",
           os.path.join("framework-standards-agent", "scripts"),
           os.path.join("structure-generator-agent", "scripts"),
           os.path.join("test-case-generator-agent", "scripts")):
    _p = os.path.join(_AGENTS, _d)
    if _p not in _sys.path:
        _sys.path.insert(0, _p)
# ----------------------------------------------------------------------

from fw_common import (base_name, ep_key, extract_endpoints, load_swagger,
                       print_table, scan_project, write_json)


def find_package_roots(root):
    """Locate the java main/test source roots and the framework base package."""
    mains = glob.glob(os.path.join(root, "**", "src", "main", "java"), recursive=True)
    tests = glob.glob(os.path.join(root, "**", "src", "test", "java"), recursive=True)
    return (mains[0] if mains else os.path.join(root, "src", "main", "java"),
            tests[0] if tests else os.path.join(root, "src", "test", "java"))


def endpoint_slug(ep):
    slug = ep["path"].strip("/").replace("/", "_").replace("{", "").replace("}", "_")
    return "%s__%s" % (ep["method"], slug.lower())


def plan_endpoint(ep, module, main_root, test_root, root):
    base = base_name(ep)
    cls = base[:1].upper() + base[1:]
    mod_l = module.lower()
    rel = lambda p: os.path.relpath(p, root).replace("\\", "/")
    config_files = [rel(p) for p in glob.glob(
        os.path.join(root, "**", "config-*.properties"), recursive=True)]
    plan = {
        "endpoint": ep_key(ep),
        "cacheFile": ".github/agent-cache/%s/%s.cache.yaml" % (module, endpoint_slug(ep)),
        "configKey": "%s.%s.path" % (mod_l, base.lower()),
        "configFiles": config_files or ["src/test/resources/config/config-QA.properties"],
        "endpointEnumConstant": base.upper() if base.isupper() else
            "".join("_" + c if c.isupper() else c.upper() for c in base).lstrip("_"),
        "artifacts": {
            "endpointEnum": rel(os.path.join(main_root, "**", mod_l, "%sEndpoint.java" % module)),
            "dto": rel(os.path.join(main_root, "**", mod_l, "dto", "%sDto.java" % cls)),
            "service": rel(os.path.join(main_root, "**", mod_l, "%sService.java" % module)),
            "stepDefinition": rel(os.path.join(test_root, "**", mod_l, "%sStepDef.java" % module)),
            "feature": "src/test/resources/features/%s/%s.feature" % (mod_l, cls),
            "testData": "src/test/resources/testdata/%s/%s.yaml" % (module, cls),
        },
    }
    return plan


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--swagger-file", required=True)
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--module", required=True, help="Module enum name, e.g. Alert")
    ap.add_argument("--json", help="write full plan JSON here")
    args = ap.parse_args()

    spec = load_swagger(args.swagger_file)
    eps = extract_endpoints(spec)
    inv = scan_project(args.project_root)
    main_root, test_root = find_package_roots(args.project_root)

    known_enum_keys = {c[2] for c in inv["enum_constants"]}
    plans, rows = [], []
    for ep in eps:
        p = plan_endpoint(ep, args.module, main_root, test_root, args.project_root)
        p["module"] = args.module
        p["moduleEnumExists"] = args.module.upper() in {m.upper() for m in inv["modules"]}
        p["configKeyExists"] = any(
            p["configKey"] in props for props in inv["config_files"].values())
        p["enumConstantExists"] = p["configKey"] in known_enum_keys
        plans.append(p)
        rows.append([p["endpoint"], p["configKey"],
                     "yes" if p["configKeyExists"] else "CREATE",
                     "yes" if p["enumConstantExists"] else "CREATE",
                     p["artifacts"]["testData"]])

    print_table(["Endpoint", "Config key", "Key exists", "Enum exists", "Test data"], rows)
    if not plans:
        print("No endpoints found in spec.")
    if args.json:
        write_json(args.json, {"module": args.module,
                               "moduleEnumExists": plans[0]["moduleEnumExists"] if plans else False,
                               "endpoints": plans})


if __name__ == "__main__":
    main()
