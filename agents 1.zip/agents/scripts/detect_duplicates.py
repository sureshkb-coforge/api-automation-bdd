"""Detect duplicates across the Art.Api.Automation framework:

  - endpoint enum constants / config keys reused across enum files
  - DTO class names duplicated across packages
  - Cucumber step patterns duplicated across step-definition files
  - TC IDs duplicated across feature files
  - TC keys duplicated across YAML test-data files

Usage:
  python detect_duplicates.py --project-root .   [--swagger-file ignored]

Exit code 0 = no duplicates, 1 = duplicates found.
"""
import argparse
import os
import sys
from collections import defaultdict

from fw_common import print_table, scan_project


def groups(pairs):
    """pairs of (value, location) -> {value: [locations]} with len > 1."""
    g = defaultdict(list)
    for value, loc in pairs:
        g[value].append(loc)
    return {v: locs for v, locs in g.items() if len(locs) > 1}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--swagger-file", help="accepted for CLI consistency")
    args = ap.parse_args()

    inv = scan_project(args.project_root)
    checks = {
        "Enum constant": [(c, f) for f, c, _ in inv["enum_constants"]],
        "Enum config key": [(k, "%s (%s)" % (f, c))
                            for f, c, k in inv["enum_constants"]],
        "DTO class": [(cls, d["file"]) for cls, d in inv["dtos"].items()
                      for _ in [0]],
        "Step pattern": [(p, f) for f, _, p in inv["step_patterns"]],
        "TC ID (feature)": [(s[1], s[0]) for s in inv["scenarios"] if s[1]],
        "TC key (yaml)": [(k, f) for f, k in inv["yaml_keys"]],
    }
    # DTO class names can only collide across different files
    dto_names = defaultdict(set)
    for cls, d in inv["dtos"].items():
        dto_names[os.path.basename(d["file"])].add(d["file"])
    checks["DTO class"] = [(name, f) for name, files in dto_names.items()
                           for f in files]

    rows, total = [], 0
    for kind, pairs in checks.items():
        for value, locs in sorted(groups(pairs).items()):
            total += 1
            rows.append([kind, value, str(len(locs)), "; ".join(sorted(locs))])

    if rows:
        print_table(["Type", "Duplicate value", "Count", "Locations"], rows)
    print("\n%d duplicate group(s) found." % total)
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()
