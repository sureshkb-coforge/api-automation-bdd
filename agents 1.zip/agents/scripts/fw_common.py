"""Shared helpers for Art.Api.Automation framework validation scripts.

Stdlib-only. PyYAML is used for the swagger file only if it is not JSON;
project YAML test data is parsed with regex so no dependency is required.
"""
import glob
import hashlib
import json
import os
import re
import sys

ENV_KEYS = {"QA", "UAT", "DEVINT", "DEVPRJ1", "STAGING", "PROD", "DEFAULT"}
VALID_HEADER_TYPES = {"noheader", "invalidheader"}


# ---------------------------------------------------------------- swagger ---

def load_swagger(path):
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    try:
        return json.loads(text)
    except ValueError:
        try:
            import yaml  # optional
            return yaml.safe_load(text)
        except ImportError:
            sys.exit("ERROR: swagger file is not JSON and PyYAML is not "
                     "installed. Convert %s to JSON or pip install pyyaml." % path)


def _resolve_ref(spec, ref):
    node = spec
    for part in ref.lstrip("#/").split("/"):
        node = node.get(part, {}) if isinstance(node, dict) else {}
    return node


def _body_schema(spec, op):
    # OpenAPI 3.x
    content = (op.get("requestBody") or {}).get("content") or {}
    for ctype, media in content.items():
        schema = media.get("schema") or {}
        if "$ref" in schema:
            schema = _resolve_ref(spec, schema["$ref"])
        return schema
    # Swagger 2.0 body parameter
    for p in op.get("parameters") or []:
        if p.get("in") == "body":
            schema = p.get("schema") or {}
            if "$ref" in schema:
                schema = _resolve_ref(spec, schema["$ref"])
            return schema
    return {}


def extract_endpoints(spec):
    """Return list of endpoint dicts from an OpenAPI 2/3 spec."""
    eps = []
    for path, item in sorted((spec.get("paths") or {}).items()):
        if not isinstance(item, dict):
            continue
        for method in ("get", "post", "put", "patch", "delete"):
            op = item.get(method)
            if not isinstance(op, dict):
                continue
            schema = _body_schema(spec, op)
            eps.append({
                "method": method.upper(),
                "path": path,
                "operationId": op.get("operationId") or "",
                "responses": sorted(str(c) for c in (op.get("responses") or {})),
                "required_fields": list(schema.get("required") or []),
                "has_body": bool(schema),
                "secured": bool(op.get("security", spec.get("security"))),
                "fingerprint": hashlib.sha1(
                    json.dumps(op, sort_keys=True, default=str)
                    .encode("utf-8")).hexdigest()[:12],
            })
    return eps


def ep_key(ep):
    return "%s %s" % (ep["method"], ep["path"])


def load_snapshot(path):
    """{'METHOD /path': fingerprint} from a previous --save-snapshot run."""
    if path and os.path.isfile(path):
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    return None


def save_snapshot(path, eps):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({ep_key(e): e["fingerprint"] for e in eps}, fh, indent=2)


def classify(ep, snapshot):
    """NEW / UPDATED / UNCHANGED against a snapshot, or '-' if none exists."""
    if snapshot is None:
        return "-"
    old = snapshot.get(ep_key(ep))
    if old is None:
        return "NEW"
    return "UNCHANGED" if old == ep["fingerprint"] else "UPDATED"


# ----------------------------------------------------------------- naming ---

def norm(s):
    """Lowercase alphanumeric form used for all fuzzy matching."""
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def base_name(ep):
    """Best-guess artifact base name, e.g. postAccountNickName."""
    if ep["operationId"]:
        return ep["operationId"]
    segs = [s for s in ep["path"].split("/") if s and not s.startswith("{")]
    return ep["method"].lower() + "".join(s[:1].upper() + s[1:] for s in segs)


def name_hints(ep):
    """Normalized strings any matching artifact name should contain."""
    hints = [norm(base_name(ep))]
    segs = [s for s in ep["path"].split("/") if s and not s.startswith("{")]
    if segs:
        hints.append(norm(segs[-1]))
        hints.append(norm("".join(segs)))
    return [h for h in hints if h]


def fuzzy_match(candidates, hints):
    """Candidates whose normalized name contains / is contained in a hint."""
    out = []
    for c in candidates:
        nc = norm(c)
        if nc and any(h in nc or nc in h for h in hints):
            out.append(c)
    return out


# ---------------------------------------------------------- project scan ----

def _read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def _rel(root, path):
    return os.path.relpath(path, root).replace("\\", "/")


def load_properties(path):
    props = {}
    for line in _read(path).splitlines():
        line = line.strip()
        if line and not line.startswith(("#", "!")) and "=" in line:
            k, v = line.split("=", 1)
            props[k.strip()] = v.strip()
    return props


def scan_project(root):
    """One cheap pass over the repo; returns the full artifact inventory."""
    inv = {
        "config_files": {},       # rel path -> {key: value}
        "enum_constants": [],     # (rel file, CONSTANT, config_key)
        "dtos": {},               # ClassName -> {file, request, body, projection}
        "service_methods": [],    # (rel file, method_name)
        "stepdef_files": [],      # rel paths
        "step_patterns": [],      # (rel file, annotation, pattern)
        "scenarios": [],          # (rel file, tc_id, name, n_steps, tags)
        "feature_files": [],
        "feature_regression": {},  # rel file -> bool (@Regression on Feature:)
        "yaml_files": [],
        "yaml_keys": [],          # (rel file, TC key)
        "yaml_status": {},        # (rel file, TC key) -> set(status codes)
        "yaml_children": {},      # (rel file, TC key) -> set(immediate child keys)
        "yaml_headertypes": [],   # (rel file, TC key, value)
        "modules": [],            # Module enum constants
        "base_url_modules": [],   # top-level keys in base-urls.yaml
    }

    for p in glob.glob(os.path.join(root, "**", "config-*.properties"),
                       recursive=True):
        inv["config_files"][_rel(root, p)] = load_properties(p)

    for p in glob.glob(os.path.join(root, "**", "*Endpoint.java"),
                       recursive=True):
        for m in re.finditer(r"^\s*([A-Z][A-Z0-9_]*)\s*\(\s*\"([^\"]+)\"\s*\)",
                             _read(p), re.M):
            inv["enum_constants"].append((_rel(root, p), m.group(1), m.group(2)))

    for p in glob.glob(os.path.join(root, "**", "Module.java"), recursive=True):
        m = re.search(r"enum\s+Module[^{]*\{([^;}]*)", _read(p))
        if m:
            inv["modules"] += [t.strip() for t in m.group(1).split(",")
                               if re.fullmatch(r"[A-Z][A-Z0-9_]*", t.strip())]

    for p in glob.glob(os.path.join(root, "**", "base-urls.y*ml"),
                       recursive=True):
        inv["base_url_modules"] += re.findall(r"^([A-Z][A-Z0-9_]*)\s*:",
                                              _read(p), re.M)

    for p in glob.glob(os.path.join(root, "**", "*Dto.java"), recursive=True):
        text = _read(p)
        cls = os.path.basename(p)[:-5]
        inv["dtos"][cls] = {
            "file": _rel(root, p),
            "request": bool(re.search(r"class\s+Request\b", text)),
            "body": bool(re.search(r"class\s+Body\b", text)),
            "projection": bool(re.search(r"class\s+Projection\b", text)),
        }

    for p in glob.glob(os.path.join(root, "**", "*Service.java"),
                       recursive=True):
        for m in re.finditer(
                r"public\s+(?:static\s+)?[\w.<>\[\]]+\s+(\w+)\s*\(", _read(p)):
            inv["service_methods"].append((_rel(root, p), m.group(1)))

    for p in glob.glob(os.path.join(root, "**", "*StepDef*.java"),
                       recursive=True):
        rel = _rel(root, p)
        inv["stepdef_files"].append(rel)
        for m in re.finditer(r"@(Given|When|Then)\s*\(\s*\"([^\"]+)\"",
                             _read(p)):
            inv["step_patterns"].append((rel, m.group(1), m.group(2)))

    for p in glob.glob(os.path.join(root, "**", "*.feature"), recursive=True):
        rel = _rel(root, p)
        inv["feature_files"].append(rel)
        tags, cur = [], None
        for line in _read(p).splitlines() + ["Scenario:"]:  # sentinel flush
            s = line.strip()
            if s.startswith("@"):
                tags += s.split()
            elif s.startswith("Feature:"):
                inv["feature_regression"][rel] = "@Regression" in tags
                tags = []
            elif s.startswith(("Scenario:", "Scenario Outline:")):
                if cur:
                    inv["scenarios"].append(tuple(cur))
                name = s.split(":", 1)[1].strip()
                tc = re.search(r"TC[_-]?(\w+)", name)
                cur = [rel, "TC_" + tc.group(1) if tc else "", name, 0, tags]
                tags = []
            elif cur and re.match(r"(Given|When|Then|And|But)\b", s):
                cur[3] += 1

    for p in glob.glob(os.path.join(root, "**", "testdata", "**", "*.y*ml"),
                       recursive=True):
        rel = _rel(root, p)
        inv["yaml_files"].append(rel)
        key, child_indent = None, None
        for line in _read(p).splitlines():
            if not line.strip() or line.strip().startswith("#"):
                continue
            m = re.match(r"^(TC_[A-Za-z0-9_]+)\s*:", line)
            if m:
                key, child_indent = m.group(1), None
                inv["yaml_keys"].append((rel, key))
                inv["yaml_status"].setdefault((rel, key), set())
                inv["yaml_children"].setdefault((rel, key), set())
                continue
            if not key:
                continue
            cm = re.match(r"^(\s+)([A-Za-z0-9_]+)\s*:", line)
            if cm:
                indent = len(cm.group(1))
                if child_indent is None:
                    child_indent = indent
                if indent == child_indent:
                    inv["yaml_children"][(rel, key)].add(cm.group(2))
            sc = re.search(r"\bstatusCode\s*:\s*[\"']?(\d{3})", line)
            if sc:
                inv["yaml_status"][(rel, key)].add(sc.group(1))
            ht = re.search(r"\bheaderType\s*:\s*[\"']?([A-Za-z]+)", line)
            if ht:
                inv["yaml_headertypes"].append((rel, key, ht.group(1)))
    return inv


def next_tc_id(inv, default=10001):
    """Highest numeric TC id across features + YAML, plus one."""
    ids = [0]
    for _, tc in inv["yaml_keys"]:
        m = re.match(r"TC_(\d+)$", tc)
        if m:
            ids.append(int(m.group(1)))
    for s in inv["scenarios"]:
        m = re.match(r"TC_(\d+)$", s[1] or "")
        if m:
            ids.append(int(m.group(1)))
    top = max(ids)
    return top + 1 if top else default


# --------------------------------------------------- framework rule checks --

def framework_rule_violations(inv):
    """Global convention checks from AGENT_FRAMEWORK_GUIDE.md Part D."""
    out = []
    for f, has in sorted(inv["feature_regression"].items()):
        if not has:
            out.append("%s: Feature is missing the @Regression tag" % f)
    for (f, tc), children in sorted(inv["yaml_children"].items()):
        if children and not children & ENV_KEYS:
            out.append("%s %s: not env-nested (children %s) - YamlUtil will "
                       "leak the whole block; nest under QA/UAT/.../DEFAULT"
                       % (f, tc, sorted(children)))
    for f, tc, val in sorted(inv["yaml_headertypes"]):
        if val.lower() not in VALID_HEADER_TYPES:
            out.append("%s %s: headerType '%s' is not noHeader/invalidHeader "
                       "- it silently falls back to standard headers "
                       "(possible typo)" % (f, tc, val))
    if inv["modules"] and inv["base_url_modules"]:
        for mod in sorted(set(inv["modules"]) - set(inv["base_url_modules"])):
            out.append("Module enum '%s' has no block in base-urls.yaml - "
                       "first call will throw IllegalStateException" % mod)
        for mod in sorted(set(inv["base_url_modules"]) - set(inv["modules"])):
            out.append("base-urls.yaml block '%s' has no Module enum constant "
                       "(dead config)" % mod)
    return out


# ----------------------------------------------------------------- output ---

def print_table(headers, rows):
    rows = [[str(c) for c in r] for r in rows]
    widths = [max([len(h)] + [len(r[i]) for r in rows])
              for i, h in enumerate(headers)]
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(line)
    print("| " + " | ".join(h.ljust(w) for h, w in zip(headers, widths)) + " |")
    print(line)
    for r in rows:
        print("| " + " | ".join(c.ljust(w) for c, w in zip(r, widths)) + " |")
    print(line)


def write_json(path, data):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    print("\nJSON written: %s" % path)
