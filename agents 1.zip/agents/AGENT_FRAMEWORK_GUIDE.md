# Art.Api.Automation — Deep-Dive Framework Guide (for Claude Agent Configuration)

> This is a **file-by-file internal-logic reference**, not a summary. For every unique file in the
> framework it documents: what it does line-by-line, its exact inputs/outputs, which files it calls
> (dependencies), and which files call it (dependents). Use this to configure a Claude agent so it
> understands the *real* runtime behavior — not just naming conventions — before generating new code.

---

## PART A — Two Competing Request Pipelines (IMPORTANT — read first)

This codebase actually contains **two parallel execution pipelines**. An agent MUST use pipeline #1
for all new work. Pipeline #2 is legacy/frozen — never extend it, only read it to avoid confusing it
with the real pattern.

### Pipeline #1 — "Module-aware" pipeline (CURRENT / CORRECT — use this for all new endpoints)
```
Feature step "I load test case schema" (VancityStepDef.iLoadTestCaseSchema)
  → YamlUtil.getByTestCaseId → TestDataRandomizer.resolveRandoms → TestDataSubstitutor.resolve
  → TestDataContext.putAll(...)
Feature step "I call <X> API" (<Endpoint>StepDef — ONE LINE)
  → <Module>Service.<method>(headerType)
      → PayloadBuilder.buildFromContext(Dto.Request.class)
      → <Module>Endpoint.<CONST>.getPath() → ConfigLoader.get(configKey)   [only the URL PATH, e.g. "/accountnickname"]
      → APIClient.post(Module.<MODULE_ENUM>, path, payloadJson, headerType)
          → resolveSpec(module, headerType)
              → RequestSpecFactory.createSpec / createSpecNoCorrelation / createSpecInvalidCorrelation(module)
                  → BaseUrlResolver.resolve(module)   [reads base-urls.yaml — the REAL base URL, per module+env]
                  → buildDefaultHeaders()              [x-api-key, x-correlation-id, storeNumber, clientId, userId, Vancity-CIAM-Authorization]
                  → attaches RequestResponseLoggingFilter (captures into PayloadCaptor)
          → RestAssured.given(spec).body(payload).post(path)
          → handle429() retry loop (exponential backoff, honours Retry-After header)
          → applyApiCallDelay() (fixed pause after every call)
      → ResponseContext.storeResponse("lastResponse", response)
      → deserialize(response, Dto.Projection.class)   [Jackson, ignores unknown fields]
      → TestDataContext.put("_projection", proj)
Feature step "Then I should receive status code from test data"
  → VancityStepDef.iShouldReceiveStatusCodeFromTestData()
  → compares TestDataContext("statusCode") vs ResponseContext.getResponse("lastResponse").getStatusCode()
```
**Base URL source of truth for Pipeline #1 = `base-urls.yaml`** (keyed by `Module` enum name + env),
NOT `config-QA.properties#baseURL`. The `config-*.properties#baseURL` key is only used by the legacy
pipeline below and by `TestConfig`/`APIClient`'s flat (non-module) methods.

### Pipeline #2 — "Legacy flat" pipeline (DO NOT extend — read-only reference)
Used by older steps still present in `VancityStepDef.java` (e.g. `iPerformGETRequestUsingTestData`,
`iPerformPOSTRequestUsingTestData`, `performGetOperationForIndividualUserHavingEndpoint...`).
```
APIClient.get(endpoint)/get(endpoint, headerDetails)/post(endpoint, payload)
  → RestAssured.baseURI = ConfigLoader.get("baseURL")      [flat property, ignores Module]
  → hardcoded header injection inline in APIClient (UUID x-correlation-id, or a FIXED
    literal "2eb6f1e8080b" for GET / "AFDS$%56" for POST when headerType != "NoHeader" — NOT randomized correlation for the "has invalid header" case)
  → same handle429 retry + applyApiCallDelay
```
This pipeline pre-dates `RequestSpecFactory`/`BaseUrlResolver`/`Module` and is kept only so
older feature files (that call the generic `VancityStepDef` GET/POST steps with inline endpoint
strings) keep working. **New endpoints must use Pipeline #1 (Service + Module-aware APIClient
methods) exclusively.**

---

## PART B — File-by-File Deep Dive

Each entry: **Path | Role | Inputs → Outputs | Internal logic | Depends on | Used by**

### `base/Endpoint.java`
- **Role:** Marker interface every `<Module>Endpoint` enum implements.
- **Logic:** Declares `String getPath()`. Also ships a **default method** `buildPath(String... values)`
  that regex-replaces `{placeholder}` tokens in the path left-to-right and returns an anonymous
  `Endpoint` lambda wrapping the resolved string. Throws `IllegalArgumentException` on arg-count mismatch.
- **Depends on:** nothing (pure interface + java.util.regex).
- **Used by:** every `endpoint/<Module>/<Module>Endpoint.java` enum; `RestClient` (legacy) takes
  `Endpoint` instances directly.
- **Note:** `buildPath` is NOT used in the current endpoint enums (they only use `getPath()` directly,
  appending path/query params as raw string concatenation in the Service). It exists for future
  templated-path use.

### `base/BaseTest.java`
- **Role:** TestNG suite lifecycle bootstrap. Not a step def — it's a base class other test classes
  could extend (Cucumber runner itself does NOT extend it directly in this repo's current wiring —
  `TestNGRunner extends AbstractTestNGCucumberTests`, not `BaseTest`; `BaseTest` is a legacy/parallel
  scaffold kept for non-Cucumber TestNG suites or future direct use).
- **`@BeforeSuite` logic:** ensures `logs/` dir exists → `ConfigLoader.initializeEnvironment()` (reads
  `-Denv`) → ensures `logs/`, `reports/`, `config/` dirs → `ConfigLoader.loadProperties()` →
  `ExtentManager.initReports()` → `GlobalContext.clear()`.
- **`@AfterSuite` logic:** `GlobalContext.dumpContext()` (logs all keys) → `ExtentManager.flushReports()`.
- **`@BeforeClass`/`@AfterClass`:** initializes/tears down `DatabaseConnectionManager` connection pool
  (best-effort; failures only logged as warnings, do not fail the suite).
- **Depends on:** `FileSystemUtil`, `LoggerUtil`, `ConfigLoader`, `ExtentManager`, `GlobalContext`,
  `DatabaseConnectionManager`.
- **Used by:** nothing in the active Cucumber run path today (dead-code risk — verify before relying
  on suite-level init from this class; the actual active bootstrap for Cucumber runs is implicit:
  `ConfigLoader.loadProperties()` lazy-inits on first `.get()` call, and `Hooks.java`/`AdoHooks.java`
  handle per-scenario setup instead of `BaseTest`).

### `base/RequestSpecFactory.java`
- **Role:** ⭐ The single place that builds a REST Assured `RequestSpecification` for Pipeline #1.
- **Public methods & exact behavior:**
  - `createSpec(Module module)` → `buildSpec(BaseUrlResolver.resolve(module), buildDefaultHeaders())`
    — standard/happy-path spec.
  - `createSpecNoCorrelation(Module module)` → same headers minus `x-correlation-id` (removed after
    building defaults) — used when `headerType == "noHeader"`.
  - `createSpecInvalidCorrelation(Module module)` → same headers but `x-correlation-id` overwritten
    with the literal `"INVALID-CORRELATION-!!!"` — used when `headerType == "invalidHeader"`.
  - `createSpecWithHeaderOverrides(Module, Map<String,String>)` — defaults + caller map merged on top
    (caller values win).
  - `createSpecWithExactHeaders(Module, Map<String,String>)` — ONLY the caller's headers, nothing
    auto-injected.
  - Deprecated no-`Module` overloads (`createSpec()`, etc.) fall back to
    `EnvironmentConfig.getApiBaseUrl()` (flat/global URL) — legacy path, do not use for new work.
- **`buildDefaultHeaders()` internal logic (exact order matters):**
  1. Reads `EnvironmentConfig.current().getName()`; if env is `DEVINT` or `DEVPRJ1`, **skips**
     `x-api-key` entirely (these envs don't require it). Otherwise sets
     `x-api-key = TokenManager.getApiKey()`.
  2. Always sets `x-correlation-id = UUID.randomUUID().toString()`.
  3. `storeNumber` — resolved from `TestDataContext.get("storeNumber")` if present/non-blank, else
     fallback literal `"autoTester"`.
  4. `clientId` — from `TestDataContext.get("clientId")`, else fallback `"MY_APP"`.
  5. `userId` — from `TestDataContext.get("userId")`, else fallback `"autoTester"`.
  6. `Vancity-CIAM-Authorization` — from `TestDataContext.get("ciamToken")`, else
     `ConfigLoader.get("ciamToken", "")`; **header omitted entirely** if the resolved value is blank
     (so unauthenticated flows don't send an empty header).
- **`buildSpec(baseUri, headers)`:** `RequestSpecBuilder` with `setBaseUri`, `ContentType.JSON`,
  a timeout config (`CONNECT_TIMEOUT=30_000ms`, `SOCKET_TIMEOUT=60_000ms`, and `x-api-key` blacklisted
  from REST Assured's own console logging so secrets don't leak into logs), then `.filter(new
  RequestResponseLoggingFilter())` is attached so every request built from this spec is auto-captured.
- **Depends on:** `client.RequestResponseLoggingFilter`, `client.TokenManager`, `config.EnvironmentConfig`,
  `config.Module`, `utils.BaseUrlResolver`, `utils.ConfigLoader`, `utils.TestDataContext`.
- **Used by:** `client.APIClient` (`resolveSpec()` — the ONLY caller in the active pipeline).

### `base/RestClient.java`
- **Role:** Legacy static wrapper offering GET/POST/PUT/PATCH/DELETE against an `Endpoint` instance,
  using the **deprecated no-Module** `RequestSpecFactory` methods. Not called by any current Service
  class (`AccountsService` etc. use `APIClient`, not `RestClient`). Kept for potential direct-use call
  sites or historical tests. **Do not use for new endpoints** — use `APIClient` inside a `Service`.

### `base/TestConfig.java`
- **Role:** Builds the plain/flat `RequestSpecification` used by `APIClient`'s **constructor** and its
  non-module GET/POST methods (Pipeline #2). `getDefaultRequestSpec()` sets `baseURI = ConfigLoader.get("baseURL")`
  and `x-api-key` header. `applyDefaultConfig()` sets this as REST Assured's global default spec
  (not invoked anywhere in the active Cucumber flow — dead code safety net).
- **Used by:** `APIClient()` constructor only (to initialize `this.requestSpecification`, a field that
  is actually **unused** by the module-aware GET/POST methods — those build a fresh spec per call via
  `resolveSpec`). The field is only relevant to the legacy flat methods indirectly via
  `RestAssured.baseURI` reassignment inside `executeGet`/`executePost`.

### `client/APIClient.java`
- **Role:** ⭐ THE HTTP execution engine. Instantiated once per Service class as a `private static final
  APIClient CLIENT = new APIClient()`.
- **Constructor:** builds `requestSpecification` via `TestConfig.getDefaultRequestSpec()` (see above —
  mostly vestigial for the module-aware path).
- **Rate-limit config readers** (all with safe hardcoded fallbacks if config key missing/unparsable):
  - `getApiCallDelay()` ← `apiCallDelayMs` (default `2000`ms)
  - `getMaxRetryOn429()` ← `maxRetryOn429` (default `3`)
  - `getRetryOn429BaseDelay()` ← `retryOn429BaseDelayMs` (default `5000`ms)
- **`applyApiCallDelay()`** — `Thread.sleep(delay)` after every single HTTP call, always, regardless
  of success/failure (unless delay is 0).
- **`handle429(Response, attemptNumber)`** — called in a `do { ... } while(handle429(...))` loop after
  every request:
  - Returns `false` immediately if status != 429 (loop exits, response returned as-is).
  - If `attemptNumber > maxRetries` → logs warning, returns `false` (gives up, returns last 429 as-is).
  - Else computes wait: prefers the `Retry-After` response header (parsed as seconds → ms); if
    missing/unparsable, uses exponential backoff `baseDelay * 2^(attempt-1)`, capped at `60_000`ms.
  - Sleeps, returns `true` (loop retries the same request).
- **Flat/legacy methods** (`get(String)`, `get(String,String headerDetails)`, `post(String,Object)`,
  `post(String,Object,String header)`, `get(String,int maxRetries)` via `RetryUtil`):
  - Set `RestAssured.baseURI = ConfigLoader.get("baseURL")` (global flat URL — ignores Module).
  - `executeGet(endpoint)` — always injects a fresh random `x-correlation-id` UUID.
  - `executeGet(endpoint, headerDetails)` — if `headerDetails.equalsIgnoreCase("NoHeader")` sends NO
    correlation header; otherwise sends a **hardcoded literal** `x-correlation-id: "2eb6f1e8080b"`
    (this is the "invalid header" simulation in the legacy path — a fixed non-UUID string, not
    randomized-but-malformed).
  - `executePost(endpoint, payload, headerDetails)` — same NoHeader branch; otherwise hardcoded
    literal `x-correlation-id: "AFDS$%56"` plus explicit `Content-Type: application/json`.
  - All flat methods route through `RequestResponseLoggingFilter` and the same `handle429`/
    `applyApiCallDelay` machinery.
- **Module-aware methods (Pipeline #1 — use these):**
  - `get(Module module, String endpoint)` → `executeModuleGet(module, endpoint, "standard")`
  - `get(Module module, String endpoint, String headerType)` → `executeModuleGet(...)`
  - `post(Module module, String endpoint, Object payload)` → `executeModulePost(..., "standard")`
  - `post(Module module, String endpoint, Object payload, String headerType)` → `executeModulePost(...)`
  - `executeModuleGet`/`executeModulePost` call `resolveSpec(module, headerType)` then
    `RestAssured.given(spec).(body(payload)).when().get/post(endpoint)`, wrapped in the same
    `handle429` retry loop + `applyApiCallDelay`.
  - `resolveSpec(module, headerType)`:
    ```
    if "noHeader".equalsIgnoreCase(headerType)      → RequestSpecFactory.createSpecNoCorrelation(module)
    if "invalidHeader".equalsIgnoreCase(headerType) → RequestSpecFactory.createSpecInvalidCorrelation(module)
    else                                             → RequestSpecFactory.createSpec(module)   // includes null/"standard"/anything else
    ```
    **This is the exact switch that makes `headerType: "noHeader"` / `"invalidHeader"` in YAML work.**
    Any other string (including `null`) falls through to the full valid-header spec.
  - `DELETE` methods exist too (flat + module-agnostic), following the same pattern.
- **Depends on:** `base.RequestSpecFactory`, `base.TestConfig`, `config.Module`, `exceptions.APIException`,
  `utils.ConfigLoader`, `utils.LoggerUtil`, `utils.RequestResponseLogger`, `utils.RetryUtil`,
  `utils.PayloadCaptor` (indirectly, via the filter), `client.RequestResponseLoggingFilter`,
  `client.TokenManager`.
- **Used by:** every `<Module>Service` class (module-aware methods only); `VancityStepDef` legacy
  steps (flat methods only).

### `client/RequestResponseLoggingFilter.java`
- **Role:** A REST Assured `Filter` implementation attached to every spec built by
  `RequestSpecFactory.buildSpec()`. Runs automatically around every HTTP call made through a
  module-aware or flat REST Assured chain that uses that spec.
- **Logic:**
  1. Before firing the request: captures `requestSpec.getMethod()`, `.getURI()`, and
     `prettyJson(requestSpec.getBody())` into `PayloadCaptor` (method/uri/body setters).
  2. Calls `ctx.next(requestSpec, responseSpec)` to actually execute the HTTP call.
  3. After the response returns: captures `response.getStatusCode()` and
     `prettyJson(response.getBody().asString())` into `PayloadCaptor`.
  4. Returns the response unchanged (filter is transparent/pass-through).
  - `prettyJson(Object)` — returns `"(no body)"` if null, `"(empty body)"` if blank string; otherwise
    tries Jackson parse+re-serialize with `INDENT_OUTPUT`; on failure (non-JSON body) returns the raw
    string unchanged.
- **Depends on:** `utils.PayloadCaptor`, Jackson `ObjectMapper`.
- **Used by:** implicitly attached inside `RequestSpecFactory.buildSpec()`; also constructed directly
  inline inside `APIClient`'s legacy flat `executeGet`/`executePost` methods (`.filter(new
  RequestResponseLoggingFilter())`).

### `client/TokenManager.java`
- **Role:** One-liner: `getApiKey()` reads `ConfigLoader.get("apiKey")`, returns `""` if null (never
  null, so headers never get a literal `"null"` string).
- **Used by:** `RequestSpecFactory.buildDefaultHeaders()`, `APIClient`'s legacy `delete()` method,
  `TestConfig.getDefaultRequestSpec()`.

### `config/Module.java`
- **Role:** Enum of the 7 API modules: `ACCOUNTS, TRANSACTIONS, ALERTS, CREDITCARDS, DELEGATES,
  PAYMENTS, SECUREMESSAGE`. Purely a typed key — `.name()` (e.g. `"ACCOUNTS"`) is used to look up the
  matching top-level key in `base-urls.yaml`.
- **Used by:** every `<Module>Service` (`MODULE = Module.ACCOUNTS` constant), `BaseUrlResolver.resolve()`,
  `RequestSpecFactory`/`APIClient` module-aware method signatures.
- **Adding a new module:** add enum constant here **and** a matching top-level block in
  `base-urls.yaml` with `DEVINT/DEVPRJ1/QA/UAT/STAGING` keys.

### `config/Environment.java`
- **Role:** Enum with a hardcoded base URL per environment (`DEVINT, DEVPRJ1, QA, UAT, STAGING, PROD`).
  This is a **secondary/fallback** URL source — largely superseded by `base-urls.yaml` +
  `BaseUrlResolver` for the module-aware pipeline, but still used by `EnvironmentConfig` as the
  default when `config-<ENV>.properties#baseURL` is absent.

### `config/EnvironmentConfig.java`
- **Role:** Static singleton resolved once at class-load time (static initializer block).
- **Logic:** reads `-Denv` system property (default `"QA"`), uppercases+trims, tries
  `Environment.valueOf(name)`; falls back to `Environment.QA` on invalid value. Then computes
  `EFFECTIVE_BASE_URL` = `ConfigLoader.get("baseURL")` if present/non-blank, else the resolved
  `Environment`'s hardcoded URL.
- **`current()`** returns the `Environment` enum constant (used by `RequestSpecFactory` to check
  `"DEVINT"`/`"DEVPRJ1"` for the x-api-key skip logic, and by `BaseUrlResolver`... actually
  `BaseUrlResolver` re-reads `-Denv` itself independently, see below).
- **`getApiBaseUrl()`** returns the flat/legacy effective base URL (used by deprecated
  `RequestSpecFactory` no-Module methods and `RestClient`).

### `utils/BaseUrlResolver.java`
- **Role:** ⭐ Resolves the REAL base URL for Pipeline #1.
- **Logic:**
  1. Static initializer loads/parses `base-urls.yaml` ONCE per JVM into
     `Map<String, Map<String,String>> URL_MAP` (module name → env name → url).
  2. `resolve(Module module)`: reads `-Denv` system property directly (default `"QA"`, uppercased) —
     **independent of `EnvironmentConfig`**, so it always reflects the live `-Denv` value even if
     `EnvironmentConfig`'s static block already resolved a possibly-different default.
  3. Looks up `URL_MAP.get(module.name())`; throws `IllegalStateException` if the module has no block
     in the YAML at all.
  4. Looks up `envMap.get(envKey)`; if missing, logs a warning and **falls back to `"QA"`** for that
     module; if still missing, throws `IllegalStateException`.
- **Depends on:** `base-urls.yaml` (classpath resource), `config.Module`, `utils.LoggerUtil`.
- **Used by:** `RequestSpecFactory.createSpec/createSpecNoCorrelation/createSpecInvalidCorrelation(Module)`.
- **Adding a new module:** you MUST add its block here or every call for that module throws at runtime.

### `src/main/resources/base-urls.yaml`
- Top-level keys = `Module` enum names (`ACCOUNTS`, `TRANSACTIONS`, ...). Each has
  `DEVINT/DEVPRJ1/QA/UAT/STAGING` sub-keys with full base URLs (including the versioned path segment,
  e.g. `.../vc-onlinebanking-accounts-exp-devint-v4/v4`). **Note:** `QA` currently points at the same
  URL as `DEVINT` for every module (QA environment reuses the DEVINT backend in this framework).

### `utils/ConfigLoader.java`
- **Role:** ⭐ Loads `.properties` files; the source of all endpoint PATHs (not full base URLs) for
  Pipeline #1, and the source of the flat `baseURL` for Pipeline #2.
- **Logic:**
  1. `loadProperties()` — synchronized, idempotent (`loaded` flag + double-checked locking). Calls
     `initializeEnvironment()` (reads `-Denv`, default `"QA"`), then `loadDefaultProperties()`
     (loads `config/config.properties` if it exists — currently this file is likely a stub/shared
     defaults), then `loadEnvironmentSpecificProperties()` (loads `config/config-<ENV>.properties`,
     whose values **override** the defaults via `PROPERTIES.putAll(envProperties)`).
  2. `get(key)` — lazy-triggers `loadProperties()` if not yet loaded, then `PROPERTIES.getProperty(key)`
     (returns `null` if absent — logged-warning line is actually commented out in source, so missing
     keys fail silently until something downstream NPEs).
  3. `get(key, defaultValue)`, `getInt(key)`, `getBoolean(key)`, `containsKey(key)`, `reload()` (clears
     and re-loads — used when switching environment mid-run via `setEnvironment(env)`).
- **Depends on:** filesystem (`config/config.properties`, `config/config-<ENV>.properties` — relative
  to the process working directory, NOT the classpath), `utils.LoggerUtil`.
- **Used by:** virtually everything — `<Module>Endpoint` enums (`getPath()` → `ConfigLoader.get(configKey)`),
  `APIClient` (flat `baseURL`, rate-limit keys, `ciamToken`), `RequestSpecFactory` (`ciamToken`
  fallback), `TokenManager`, `TestConfig`, `EnvironmentConfig`, `Hooks` (`scenarioDelayMs`), `AdoHooks`.

### `endpoint/<Module>/<Module>Endpoint.java` (e.g. `AccountsEndpoint`, `AlertsEndpoint`, ...)
- **Role:** ⭐ Enum of every endpoint in a module. Each constant wraps a **config property key**
  (string), NOT the path itself.
- **Logic:** `getPath()` → `ConfigLoader.get(configKey)` — so the actual path string comes from
  `config-<ENV>.properties`, meaning the same enum constant can resolve to different literal path
  strings per environment file (e.g. `postAccNickName=/accountnickname` in QA could theoretically
  differ in UAT — check each `config-<ENV>.properties` when adding a key).
- **One enum file per module** (not per endpoint) — new endpoints add a new constant to the existing
  file for their module.
- **Used by:** the matching `<Module>Service` class only.

### `dto/<module>/<Endpoint>Dto.java`
- **Role:** ⭐ One file per endpoint. Static inner classes: `Request` (with nested `Body` matching the
  YAML `requestPayload` shape) and `Projection` (response shape).
- **Logic (Jackson):**
  - `Request`/`Body`: `@JsonInclude(NON_NULL)` — any field left `null` (not present in the YAML
    `requestPayload` map for that env) is dropped from the outgoing JSON entirely, rather than
    serialized as `null`. This is critical for negative test cases that deliberately omit a field.
  - `Projection`: `@JsonIgnoreProperties(ignoreUnknown = true)` — response deserialization never fails
    even if the API returns extra fields not modeled here; unmapped fields are silently ignored.
    Conversely, fields declared here but absent in the actual response are simply `null`/default.
  - Lombok `@Data` generates getters/setters/equals/hashCode/toString; `@Builder` enables fluent
    construction (rarely used directly since `PayloadBuilder` uses Jackson `convertValue`, not the
    builder, but builder is kept for potential manual DTO construction in future code).
- **Naming rule:** the outer `Request.<fieldName>` must exactly match the top-level key under
  `requestPayload:` in YAML (Jackson maps by field name during `convertValue`). E.g.
  `AccountNickNameDto.Request.accountNickname` ↔ YAML `requestPayload.accountNickname`.

### `utils/PayloadBuilder.java`
- **Role:** ⭐ Converts the raw `Map` (`TestDataContext.get("requestPayload")`) into a JSON string,
  either raw (`buildFromContext()`, no DTO) or typed (`buildFromContext(Class<T> dtoClass)`).
- **Logic:**
  - `buildFromContext()` — returns `null` if `requestPayload` absent; else
    `MAPPER.writeValueAsString(rawMapObject)` directly (used only by the legacy
    `iPerformPOSTRequestUsingTestData` step).
  - `buildFromContext(Class<T>)` — returns `null` if `requestPayload` absent; else
    `MAPPER.convertValue(rawMap, dtoClass)` (Jackson maps Map keys → DTO field names, applying
    `@JsonInclude(NON_NULL)` on the target type when re-serialized), then
    `MAPPER.writeValueAsString(dto)`. **This is the method every `<Module>Service` calls.**
  - Both throw `RuntimeException` wrapping `JsonProcessingException` on serialization failure.
- **Depends on:** `utils.TestDataContext`, Jackson `ObjectMapper` (plain instance, no custom modules
  registered — relies purely on Lombok-generated getters + standard bean naming).
- **Used by:** every `<Module>Service.<postX>()` method.

### `utils/YamlUtil.java`
- **Role:** ⭐ Reads `testdata/<Module>/<Feature>.yaml` from the classpath and returns the
  environment-scoped data map for a given `TC_<id>`.
- **`getByTestCaseId(featureName, testCaseId)` logic:**
  1. Builds classpath path `testdata/<featureName>.yaml` (featureName already includes the module
     folder, e.g. `"Accounts/PostAccountNickName"`).
  2. `getClassLoader().getResourceAsStream(path)` — throws `IllegalArgumentException` if the file
     isn't found on the classpath (i.e., not under `src/test/resources/`).
  3. Parses with `SnakeYAML` + `SafeConstructor` (no arbitrary Java object instantiation — safe for
     untrusted YAML).
  4. Looks up `"TC_" + testCaseId` — throws with the list of available keys if missing (helps debug
     typos).
  5. **Environment navigation:** reads `EnvironmentConfig.current().getName()` (e.g. `"QA"`); if the
     TC block has a matching sub-key, returns that sub-map; **else returns the whole TC block
     unmodified** (backward-compat for YAMLs without env nesting — meaning if you forget an env
     sub-key, the raw TC block including *all* env blocks could accidentally be passed downstream —
     always nest under an env key, or `DEFAULT`, to avoid this).
  - Legacy `slice(featureName, testCaseId)` method (older `runMode: Y/N` row-list format under a
    `DEFAULT` list) — used only by pre-migration YAMLs, not part of the current per-endpoint pattern.
- **Depends on:** `config.EnvironmentConfig`, SnakeYAML.
- **Used by:** `VancityStepDef.iLoadTestCaseSchema()` (current pattern) and
  `iLoadTestDataForTestCase()` (legacy pattern using `_featureName` from `Hooks`).

### `utils/TestDataRandomizer.java`
- **Role:** Post-processes the raw YAML map, walking every String/Map/List recursively, replacing
  recognized **token strings** with generated values (see the token table in the original guide —
  `randomUUID`, `randomEmail`, `randomPhone`, `randomFirstName/LastName`, `randomInt(min,max)`,
  `randomDate(pattern)`, `randomDateMinus(days,pattern)`, `randomDatePlus(days,pattern)` — dates use
  `America/Chicago` zone). Runs BEFORE `TestDataSubstitutor` in `iLoadTestCaseSchema`.
- **Logic:** exact string match against known token literals/patterns; anything not matching a known
  token is returned unchanged (so ordinary YAML values pass through untouched).
- **Used by:** `VancityStepDef.iLoadTestCaseSchema()` and `iLoadTestDataForTestCase()`, always applied
  first, before substitution.

### `utils/TestDataSubstitutor.java`
- **Role:** Second pass over the (already randomized) map — replaces `{{key}}` placeholders with
  values from `TestDataContext` (cross-scenario or previously-set values, e.g. an account number
  captured from an earlier GET call and referenced in a later POST's YAML via `{{accountNumber}}`).
- **Logic:**
  - Exact match `"{{key}}"` (whole string) — replaces with the **raw typed object** from
    `TestDataContext` (preserves type — e.g. if context holds a `List`, you get a `List` back, not a
    stringified version). Falls back to the original literal string if the key isn't in context yet
    (allows a later step to resolve it, or intentionally leaves the placeholder visible for debugging).
  - Embedded match (placeholder inside a longer string, e.g. `"/orders/{{orderId}}/details"`) —
    string-substitutes with `String.valueOf(value)`; unresolved placeholders are left as-is.
- **Used by:** same two `VancityStepDef` steps, always applied after `TestDataRandomizer`.

### `utils/TestDataContext.java`
- **Role:** ⭐ The central `ThreadLocal<Map<String,Object>>` scenario data bag. Every schema-loaded
  field (`statusCode`, `headerType`, `requestPayload`, any custom YAML keys) lives here for the
  duration of one scenario.
- **Key methods:** `put/get/getString/containsKey/putAll/clear/snapshot`.
- **Lifecycle:** populated by `iLoadTestCaseSchema` (or `iLoadTestDataForTestCase`), read by the
  step def → Service → `PayloadBuilder`/`RequestSpecFactory` (header resolution), cleared in
  `Hooks.afterScenario()`. Thread-local means parallel scenario execution (if ever enabled — currently
  `TestNGRunner.scenarios()` uses `@DataProvider(parallel = false)`, so effectively sequential today)
  would still be scenario-isolated.

### `utils/ResponseContext.java`
- **Role:** ⭐ Stores the raw REST Assured `Response` object (not just status/body) keyed by string,
  always `"lastResponse"` in current usage. Backed by `ConcurrentHashMap` (not ThreadLocal — meaning if
  parallel execution were ever enabled, `"lastResponse"` could be overwritten across threads; this is
  a latent bug if `parallel = true` is ever flipped in `TestNGRunner`).
- Also offers `storeExtractedData`/`getExtractedData` (JSONPath extraction into `GlobalContext` too —
  used by legacy steps like `theResponseShouldContainField`), and `dumpContext()`/`clearAll()`.
- **Used by:** every `<Module>Service` method (`storeResponse("lastResponse", response)`) and
  `VancityStepDef.iShouldReceiveStatusCodeFromTestData()` / field-assertion steps.

### `utils/PayloadCaptor.java`
- **Role:** ThreadLocal capture point populated exclusively by `RequestResponseLoggingFilter`. Holds
  last request method/uri/body and response status/body as plain strings/ints — purely for **Extent
  report rendering** in `Hooks.afterScenario()`, decoupled from `ResponseContext` (which holds the
  actual typed `Response` object used for assertions). Cleared in `Hooks.afterScenario()`.

### `services/<Module>/<Module>Service.java` (e.g. `AccountsService`)
- **Role:** ⭐ One static-method-per-endpoint façade. Owns the entire request lifecycle for its module.
- **Structure per method (POST example, `postAccountNickName`):**
  1. `PayloadBuilder.buildFromContext(XxxDto.Request.class)` → JSON string (or `null` if no
     `requestPayload` in the loaded schema — some GET-only or header-only negative tests have none).
  2. `<Module>Endpoint.<CONST>.getPath()` → resolves the URL PATH (not base URL) via `ConfigLoader`.
  3. `executePost(url, payload, headerType)` → thin private wrapper → `CLIENT.post(MODULE, url,
     payload, headerType)` (module-aware Pipeline #1 call).
  4. `ResponseContext.storeResponse("lastResponse", response)`.
  5. `deserialize(response, XxxDto.Projection.class)` — private helper wraps
     `MAPPER.readValue(response.body().asString(), clazz)` in try/catch; on failure, logs a warning
     and returns `null` (never throws — so a malformed/non-JSON error body won't crash the test before
     the status-code assertion runs).
  6. `TestDataContext.put("_projection", proj)` — makes the typed response available to any later
     field-assertion step.
  7. `return proj`.
- **GET methods** follow the same shape but build the URL by string-concatenating path params via a
  private `safe(String value)` helper (`returns value or "" if null/empty`) — e.g.
  `GET_ACCOUNT_SUMMARY.getPath() + safe(accountNumber) + safe(cifId)`. **No URL-encoding is applied** —
  path/query params are raw string concatenation, so callers must pre-format query strings (e.g. the
  `cifId` value itself often already includes the leading `?cifId=` in YAML, as seen in
  `VancityStepDef`'s legacy `appendIfPresent` javadoc example).
- **`safe()` and `deserialize()` are duplicated verbatim in every Service class** (not shared via a
  base class) — when adding a new module's Service, copy this exact boilerplate.
- **Depends on:** `client.APIClient` (instantiated once, static final), `config.Module`,
  `endpoint.<Module>.<Module>Endpoint`, `dto.<module>.*`, `utils.PayloadBuilder`,
  `utils.ResponseContext`, `utils.TestDataContext`, Jackson `ObjectMapper`.
- **Used by:** exactly one `<Endpoint>StepDef` per method.

### `stepdefinitions/<module>/<Endpoint>StepDef.java`
- **Role:** ⭐ One `@When` step per endpoint, exactly one line: reads `headerType` (and any path
  params like `cifId`) from `TestDataContext`, calls the matching Service method. No assertions, no
  payload building, no endpoint resolution — 100% delegation.
- Some endpoints need extra params — pattern seen in the codebase: read each needed field with
  `TestDataContext.getString("fieldName")` and pass positionally to the Service method matching its
  signature (e.g. `postAccountSummary(cifId, headerType)`).

### `stepdefinitions/VancityStepDef.java`
- **Role:** Shared/reusable step library. Contains BOTH the current pattern's two universal steps
  (`iLoadTestCaseSchema`, `iShouldReceiveStatusCodeFromTestData`) AND ~30 legacy steps from
  Pipeline #2 (excel-based, DataTable-based, inline-endpoint-string GET/POST steps like
  `Perform get operation for individual user having endpoint {string} with {string} and {string}`).
- **Current-pattern steps (the only ones new features should reference):**
  - `iLoadTestCaseSchema(testCaseId, featureName)` — see Pipeline #1 above; also pushes an Extent log
    line via `ExtentCucumberAdapter.addTestStepLog(...)`.
  - `iShouldReceiveStatusCodeFromTestData()` — `assertEquals(actual, Integer.parseInt(expected))`,
    TestNG assertion (fails the scenario, not a silent log, on mismatch).
  - `theResponseShouldContainFieldFromTestData()` — optional field assertion; **skipped silently**
    (no-op) if `fieldName` isn't set in the loaded YAML — supports comma-separated field names with
    `#`-separated expected values for multi-field checks in one step.
- **Legacy steps** — read/understand only if modifying an OLD feature file; never model new step defs
  on these patterns (they hardcode endpoint strings/excel rows directly in Gherkin, which violates the
  "no hardcoded data in Java/feature files" rule for new work).
- **`appendIfPresent(url, key)` private helper** (used by legacy GET/POST-using-test-data steps) —
  appends `TestDataContext` value to the URL only if present; used for query-string style params that
  are pre-formatted with a leading `?`/`&` inside the YAML value itself.

### `stepdefinitions/Hooks.java`
- **Role:** ⭐ Cucumber lifecycle glue for EVERY scenario (order 0 — runs first among `@Before`s /
  last among `@After`s relative to `AdoHooks`, which uses order 0/1000).
- **`@Before(order=0)` — `beforeScenario`:** logs scenario name+tags; parses `scenario.getUri()` to
  derive `_featureName` (everything after `/features/`, stripped of `.feature`) and stores it in
  `TestDataContext` — this is what makes the **legacy** `iLoadTestDataForTestCase(tcId)` step work
  without an explicit `featureName` argument (current-pattern `iLoadTestCaseSchema` takes it
  explicitly instead, so doesn't strictly need this, but it still runs every time regardless).
- **`@After(order=0)` — `afterScenario`:**
  1. Logs scenario finish + status.
  2. `logPayloadsToExtent(scenario)` — reads `_currentTestCaseId` from `TestDataContext` (renders a
     colored "TC_xxxxx" badge), then reads method/uri/reqBody/status/resBody from `PayloadCaptor` and
     writes formatted HTML (collapsible `<details>` blocks, color-coded status: green <400, red ≥400)
     into the current `ExtentTest` step. If scenario failed, adds a `Status.FAIL` log line.
  3. `PayloadCaptor.clear()`.
  4. `TestDataContext.clear()` — full scenario data wipe.
  5. `Thread.sleep(scenarioDelayMs)` (default 3000ms, from `ConfigLoader.get("scenarioDelayMs")`) —
     always runs (unless configured to 0), interruption caught+logged, doesn't fail the scenario.
- **Depends on:** `ConfigLoader`, `LoggerUtil`, `PayloadCaptor`, `TestDataContext`, ExtentReports
  Cucumber adapter.

### `stepdefinitions/AdoHooks.java`
- **Role:** Optional Azure DevOps Test Plan result publisher, driven entirely by Gherkin tags (not by
  YAML). Runs independently of `Hooks.java`.
- **`@Before(order=0)` — `initializeAdoContext`:** clears `AdoTestContext`, then scans
  `scenario.getSourceTagNames()` for 3 regex patterns (case-insensitive, `@`-stripped):
  - `PLAN_ID_TAG_PATTERN` — `^(?:ado_)?plan(?:id)?[_-](.+)$` → `AdoTestContext.setPlanId(...)`
  - `SUITE_ID_TAG_PATTERN` — similar for suite → `setSuiteId`
  - `TEST_CASE_ID_TAG_PATTERN` — matches `testcase`/`testcaseid`/`tc` prefix → `setTestCaseId`
  - None of the current feature files actually carry these tags (they use
    `@<EndpointName>Success`/`ErrorHandling` tags instead) — so in practice this context stays empty
    unless a scenario is explicitly tagged e.g. `@planid-597733`.
- **`@After(order=1000)` — `publishResultToAzureDevOps`:** runs LAST (highest order value runs last
  among `@After`s) so it captures the final scenario status. Maps Cucumber status → `"Passed"` /
  `"Failed"` / `"NotExecuted"`, builds a text comment (scenario name, status, environment, timestamp,
  plan/suite/testcase IDs if set), calls `AzureDevOpsTestResultPublisher.publishScenarioResult(...)`.
  Always clears `AdoTestContext` in a `finally` block. Errors are caught and logged, never rethrown
  (a failed ADO publish never fails the actual test scenario).
- **Gate:** actual publishing only happens if `ado.enabled=true` in config (checked inside
  `AzureDevOpsTestResultPublisher`, not shown here) — defaults to `false` in `config-QA.properties`.

### `runners/TestNGRunner.java`
- **Role:** ⭐ Cucumber entry point. `@CucumberOptions`: `features="src/test/features"`,
  `glue="stepdefinitions"` (package-relative, picks up `Hooks`, `AdoHooks`, `VancityStepDef`, and every
  `<module>` sub-package step def), `tags="@Regression"` (so `mvn test` alone only runs
  `@Regression`-tagged features — every feature file's `Feature:` line carries this tag), plugins:
  pretty console + summary + Cucumber HTML/JSON reports + ExtentCucumberAdapter.
  `monochrome=true` for clean console output.
- **`scenarios()` override:** wraps `super.scenarios()` in try/catch, rethrows as unchecked
  `RuntimeException` with logging on failure (fail-fast if feature/glue wiring is broken, e.g. typo in
  a package name).
- **`@DataProvider(parallel = false)`** — scenarios currently run **sequentially**, not in parallel,
  despite several classes being ThreadLocal/thread-safe in anticipation of future parallelization.

### `reports/ExtentManager.java`
- **Role:** Singleton `ExtentReports` instance (separate from the Cucumber-adapter-driven report used
  by `Hooks`/`ExtentCucumberAdapter` — this one writes `reports/manual-extent-report.html` via
  `ExtentSparkReporter`, intended for **non-Cucumber/manual** TestNG usage, e.g. if `BaseTest` were
  ever wired into a plain TestNG suite). `initReports()` is idempotent (`if (extentReports == null)`).
  `flushReports()` writes the file to disk. Not part of the active Cucumber report path (that uses the
  separate `com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter` plugin configured in
  `TestNGRunner`, whose report path/theme come from `extent.properties`, not this class).

### `utils/RetryUtil.java`
- **Role:** Generic exponential-backoff retry helper — NOT the same mechanism as `APIClient`'s 429
  handling (which is bespoke/inline). `executeWithRetry(name, Supplier<T>, maxAttempts, initialDelayMs)`
  retries on ANY exception (not just 429), doubling delay each attempt, capped at 30 000ms. Used only
  by `APIClient.get(String, int maxRetries)` / `post(String, Object, int maxRetries)` — the legacy
  flat overloads with an explicit retry count; **not used by the module-aware Pipeline #1 methods**,
  which rely solely on `handle429`.

### `utils/RequestResponseLogger.java`
- **Role:** Plain text console/log4j-style logging via `LoggerUtil` (method/endpoint/headers/body for
  requests; status/statusLine/headers/time/prettyBody for responses). Called explicitly inside
  `APIClient`'s private `execute*` methods after every response (`RequestResponseLogger.logResponse(response)`)
  — this is separate from and in addition to `PayloadCaptor`'s capture (which feeds the Extent HTML
  report) — `RequestResponseLogger` only writes to the plain log file/console via `LoggerUtil`.

### `utils/GlobalContext.java`
- **Role:** `ConcurrentHashMap`-backed, JVM-wide (not thread-local, not scenario-scoped) key-value
  store. Used sparingly — `ResponseContext.storeExtractedData` mirrors values here too, and
  `BaseTest`/legacy code clear/dump it at suite boundaries. Not part of the mainstream per-scenario
  data flow (`TestDataContext` is scenario-scoped and used for that); `GlobalContext` is for genuinely
  cross-scenario/cross-suite state if ever needed (e.g. a token fetched once and reused by all
  scenarios) — no current endpoint uses it directly.

### `exceptions/*.java`
- `APIException` — thrown by `APIClient` on unexpected HTTP execution failures (wraps root cause).
- `APIAutomationException`, `ConfigException`, `DatabaseException`, `DataException` — narrower
  exception types for their respective subsystems (config loading, DB connectivity, data parsing);
  used inconsistently — several catch blocks in `ConfigLoader`/`BaseTest` still throw plain
  `RuntimeException` rather than these typed exceptions.

### `config/config-<ENV>.properties`
- Flat `key=value` properties. Two categories of keys:
  1. **Endpoint path keys** — referenced by `<Module>Endpoint` enums via `ConfigLoader.get(configKey)`
     (Pipeline #1 — only the PATH portion, base URL comes from `base-urls.yaml` instead).
  2. **Global/legacy keys** — `baseURL` (flat base URL, Pipeline #2 + deprecated `RequestSpecFactory`
     methods), `apiKey`, `ciamToken`, rate-limit settings (`apiCallDelayMs`, `scenarioDelayMs`,
     `maxRetryOn429`, `retryOn429BaseDelayMs`), ADO settings (`ado.enabled`, `ado.organizationUrl`,
     `ado.project`, `ado.pat`, `ado.planId`, `ado.suiteId`, `ado.testCaseId`).
- **When adding a new endpoint:** add its path key to ALL THREE env files that exist
  (`config-QA.properties`, `config-UAT.properties`, `config-DEVINT.properties`) even if the path value
  is identical across environments — `ConfigLoader` does NOT fall back from one env file to another
  for a missing key beyond the shared `config.properties` defaults layer.

---

## PART C — Dependency Graph Summary (who calls whom)

```
Feature file (.feature)
  └─ Cucumber picks up via TestNGRunner (glue=stepdefinitions)
       └─ Hooks.beforeScenario / AdoHooks.initializeAdoContext   [@Before]
       └─ VancityStepDef.iLoadTestCaseSchema
            ├─ YamlUtil.getByTestCaseId ──uses──> EnvironmentConfig.current()
            ├─ TestDataRandomizer.resolveRandoms
            ├─ TestDataSubstitutor.resolve ──uses──> TestDataContext.get (cross-refs)
            └─ TestDataContext.putAll / put("_currentTestCaseId")
       └─ <Endpoint>StepDef.<method>()
            └─ <Module>Service.<method>(headerType, ...params)
                 ├─ PayloadBuilder.buildFromContext(Dto.Request.class) ──uses──> TestDataContext.get("requestPayload")
                 ├─ <Module>Endpoint.<CONST>.getPath() ──uses──> ConfigLoader.get(configKey)
                 ├─ APIClient.post/get(Module, path, payload?, headerType)
                 │    ├─ resolveSpec(module, headerType)
                 │    │    └─ RequestSpecFactory.createSpec*(module)
                 │    │         ├─ BaseUrlResolver.resolve(module) ──reads──> base-urls.yaml
                 │    │         ├─ buildDefaultHeaders() ──uses──> TokenManager, EnvironmentConfig, TestDataContext, ConfigLoader
                 │    │         └─ attaches RequestResponseLoggingFilter ──writes──> PayloadCaptor
                 │    ├─ handle429 retry loop
                 │    ├─ applyApiCallDelay (Thread.sleep)
                 │    └─ RequestResponseLogger.logResponse ──writes──> plain logs (via LoggerUtil)
                 ├─ ResponseContext.storeResponse("lastResponse", response)
                 ├─ deserialize(response, Dto.Projection.class)   [Jackson, swallow errors→null]
                 └─ TestDataContext.put("_projection", proj)
       └─ VancityStepDef.iShouldReceiveStatusCodeFromTestData
            └─ TestDataContext.getString("statusCode")  vs  ResponseContext.getResponse("lastResponse").getStatusCode()
       └─ Hooks.afterScenario / AdoHooks.publishResultToAzureDevOps   [@After]
            ├─ logPayloadsToExtent ──reads──> PayloadCaptor, TestDataContext("_currentTestCaseId")
            ├─ PayloadCaptor.clear(); TestDataContext.clear()
            └─ Thread.sleep(scenarioDelayMs)
```

---

## PART D — Rules Recap for Code Generation (unchanged, now backed by the logic above)

1. New endpoints ALWAYS use Pipeline #1 (`Module`-aware `APIClient` methods via a `<Module>Service`).
   Never call `RestClient`, `TestConfig`, or the flat/legacy `APIClient` overloads for new work.
2. `headerType` in YAML only recognizes exactly two special values, case-insensitively:
   `"noHeader"` and `"invalidHeader"`. Anything else (including omitted/`null`) → full valid headers.
3. DTO `Request.Body` field names must exactly match YAML `requestPayload` map keys (Jackson
   `convertValue` maps by name — no `@JsonProperty` aliasing is used in this codebase's DTOs today).
4. Adding a new `Module` requires a new block in `base-urls.yaml` — omitting it throws
   `IllegalStateException` at first call, not at startup (fails on first test using that module).
5. Adding a new endpoint's path key must go into **every** `config-<ENV>.properties` file that exists,
   not just QA.
6. Never let a Service's `deserialize()` throw — it must log-and-return-`null` on failure so the
   subsequent status-code assertion (the real pass/fail signal in nearly every scenario) still runs.
7. `ResponseContext` is a `ConcurrentHashMap` (not thread-local) — if the framework is ever switched to
   `parallel = true` in `TestNGRunner`, `"lastResponse"` needs a scenario-unique key or it WILL race
   between parallel scenarios. Flag this to a human if asked to enable parallel execution.
