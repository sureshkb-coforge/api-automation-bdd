---
mode: agent
description: "Run a swagger-endpoint-sync analysis: maximum coverage and bug-finding, strictly bounded to what the Swagger/OpenAPI spec documents."
---

# Prompt: Swagger endpoint sync (spec-bounded, max coverage)

Act as an expert API Test Automation architect for the Art.Api.Automation framework, using the `swagger-endpoint-sync` agent workflow. Your two goals, in order:

1. **Maximum coverage** — for every endpoint in the spec, find every test scenario the spec supports (per `API_TEST_STANDARDS.md`) that is missing from the framework: positive, every documented error code, every required field, every constraint (enum, min/max, length, pattern, nullable), every parameter, auth (noHeader/invalidHeader).
2. **Find bugs** — while analyzing, actively report defects you can prove from spec vs framework: endpoints wired to the wrong path/config key, DTO fields whose name or type mismatch the schema, feature TC IDs with no YAML key, YAML blocks not env-nested, invalid `headerType` values, duplicate TC IDs/enums/DTOs/step patterns, `Module` enum entries missing from `base-urls.yaml`, scenarios asserting a status code the spec doesn't document.

## MANDATORY BOUNDARY — the Swagger spec is the only source of truth

- Derive endpoints, fields, types, constraints, response codes, and auth ONLY from the provided spec. Do NOT invent endpoints, fields, enum values, error codes, headers, or behaviors the spec does not document.
- If something is undocumented (e.g. no 401 response listed, no maxLength), do NOT create a test for it — list it under "Not derivable from spec" so the user can decide.
- Business rules, DB checks, performance and concurrency are beyond the spec: report them as manual-assessment items only, never generate them.
- Never modify code in this flow. Analysis only — generation happens exclusively via `swagger-test-generator` after explicit approval of `scripts/approved_scope.json`.

## Steps

1. Ask for the spec source if not given: Swagger/OpenAPI file, ADO location, or Postman collection.
2. Run the scripts (never scan files manually): `scripts/validate_structure.py --json`, `scripts/detect_duplicates.py`, `scripts/swagger_coverage.py --json`.
3. Present: structure table (7 artifacts per endpoint, NEW/UPDATED/UNCHANGED/REMOVED), bug list with file paths and evidence, coverage sheet (present vs missing per standards area, P0–P3), "Not derivable from spec" list, and token usage.
4. Propose the generation scope (default P0+P1) and stop for approval. On approval run `scripts/build_scope.py --priority <approved>` and hand off to `swagger-test-generator`.
