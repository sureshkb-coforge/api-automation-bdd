# Standard API Endpoint Validation Test Pattern

For every endpoint in a Swagger/OpenAPI spec, generate/assess test cases across these 12 areas:

1. Positive validation
2. Required-field validation
3. Field-level negative validation
4. Headers and authentication
5. Path and query parameters
6. Business rules
7. Response contract
8. Security and authorization
9. Edge and boundary cases
10. File-upload validation (when applicable)
11. Performance and reliability
12. Data persistence / database validation

## 0. Swagger extraction checklist (do this first, per endpoint)

Extract: HTTP method; path; path params (name, type, format, required); query params (required/optional, enum, min/max); headers (Authorization, Content-Type, Accept, correlation ID); request body required+optional fields; field datatypes; constraints (min, max, length, pattern, enum); nullable fields; nested-object required fields; array minItems/maxItems/uniqueness; content types; response codes (200, 201, 204, 400, 401, 403, 404, 409, 415, 422, 429, 500); response schemas; security scheme.

## 1. Positive cases (POS)

- All mandatory fields | mandatory+optional | mandatory only
- Min allowed values | max allowed values
- Every valid enum value | valid null for nullable fields | omit optional fields
- Valid nested objects | array with 1 item | array with max items
- Repeat with different valid data
- POST: verify returned id, `201`, `Location` header, DB record, server defaults
- GET: existing resource, each query param, filter, sort, pagination, empty result set
- PUT: full replace, all fields, omitted-field behavior, DB changes
- PATCH: one field, multiple fields, nested field, unspecified fields unchanged
- DELETE: delete, verify gone, dependent-data behavior, repeat-delete behavior

## 2. Mandatory-field cases (REQ) — for EVERY required field, incl. nested

Remove field | `null` | `""` | `" "` | tabs/newlines only | wrong datatype | remove multiple mandatory fields (all errors returned) | remove mandatory nested object | parent present but mandatory child removed | empty mandatory object `{}` | empty mandatory array `[]`.
Note: `{}`, `{"f":null}`, `{"f":""}`, `{"f":" "}` are DISTINCT cases — test separately.

## 3. Datatype validation (per field)

- **String**: valid, empty, whitespace-only, leading/trailing spaces, minLen-1, minLen, maxLen, maxLen+1, number-as-string, boolean-as-string, special chars, Unicode, emoji, newline/tab, HTML, JS text, SQL-like, extremely long.
- **Numeric**: positive, negative (if allowed), zero, min-1, min, max, max+1, decimal-for-integer, quoted number, alphabetic, boolean, null, very large, scientific notation, leading zero.
- **Boolean**: `true`, `false`; invalid: `"true"`, `"false"`, `1`, `0`, `"Y"`, `"yes"` — only documented representations accepted.
- **Date/date-time**: valid date, valid date-time, today, past, future, leap-year valid (2024-02-29) and invalid (2025-02-29), invalid month/day, wrong format, no timezone, UTC, +/- offsets, DST transition, min/max supported, empty string, numeric timestamp, date-only for date-time field.

## 4. Enum validation (per enum field)

Every valid value | invalid value | lowercase | mixed case | leading/trailing whitespace | `""` | `null` | numeric | boolean | near-miss value (e.g. `ACTIVES`). Never assume case-insensitivity unless documented.

## 5. Header validation (HDR)

Valid headers → success | missing Authorization → 401 | empty/invalid/expired/malformed token → 401 | valid token w/o permission → 403 | missing Content-Type → defined behavior | wrong Content-Type → 415 | unsupported Accept → 406 | header-name casing (must work) | duplicate Authorization → safe reject | extremely long header value | invalid/duplicate correlation ID | special chars / injection chars in headers → safe reject.
Also verify response headers: Content-Type, Cache-Control, ETag, Location, Retry-After, correlation ID, security headers.

## 6. Path parameters

Valid existing | valid non-existing → 404 | zero | negative | max length | max+1 | alpha-for-numeric | special chars | URL-encoded | spaces | empty segment | extra slash | duplicate slash | encoded slash `%2F` | SQL-like | HTML/script | another user's resource ID | deleted/inactive ID.

## 7. Query parameters

None | required only | all | unknown param | duplicate param | empty value | null-like text | page min / below min | size max / above max | negative pagination | decimal pagination | sort valid/invalid field, asc/desc | filter valid / no-data / combos | URL-encoded values | reordered params | param-name casing.

## 8. Request-body structure

Valid | empty body | missing body | `{}` | `null` | `[]` instead of object | malformed JSON | duplicate JSON keys | unknown field(s) | wrong field casing | wrong nesting | extra nesting | missing bracket | trailing comma | JSON string instead of object | oversized body. Unknown-property behavior (reject vs ignore) must be explicit and consistent.

## 9. Nested objects & arrays

- Nested: remove parent | parent null | parent `{}` | remove child object | child null | remove mandatory leaf fields | unknown child fields | wrong child datatype | primitive instead of object | array instead of object | exceed max nesting depth.
- Arrays: 1 valid item | multiple | empty | null | missing | minItems-1 | minItems | maxItems | maxItems+1 | duplicate objects/IDs | null item | empty object item | wrong-type item | one invalid among valid | wrong order (when ordered) | extremely large array.

## 10. Response contract (validate ALL, never just status code)

Status code, response time, Content-Type, body schema, mandatory fields, datatypes, formats, nullability, enums, nested/arrays, business values, response headers, correlation ID, error schema, no confidential info, DB consistency.
Error body must have: correct status, stable code, clear message, correct field name(s), ALL validation errors, no stack trace / SQL error / internal class names, correlation ID, schema matching OpenAPI.

## 11. Status codes

200/201/202/204 for success types; 400 malformed; 401 unauth; 403 forbidden; 404 not found; 405 method not allowed; 406 not acceptable; 409 conflict; 412 precondition; 415 media type; 422 semantic/business; 429 rate limit (+Retry-After); 500/502/503/504 server/dependency. Verify invalid input never returns 200, and business errors never return uncontrolled 500.

## 12. Auth & authorization (OWASP API Top 10 aligned)

- AuthN: no/valid/invalid/expired/revoked token, invalid signature, other-environment token, missing/modified claims, wrong scheme, API key wrong location.
- AuthZ (BOLA/BFLA): own record OK, another user's record forbidden, normal user vs admin endpoint, read-only user doing writes, modifying protected fields, ID swap in path/body, cross-tenant/store access, role-restricted fields. Knowing an ID must never grant access.

## 13. Business rules (not in Swagger — derive from requirements)

Valid/invalid state transitions | duplicate creation | effective/start-end dates | date-range overlap | min/max amounts | account-status restrictions | eligibility | region/role restrictions | mutually exclusive fields | conditionally mandatory fields (test both branches, e.g. paymentType=CARD requires cardNumber; CASH must reject it) | dependent fields | calculated totals, rounding, tax | retry/duplicate submission.

## 14. Combination testing

Pairwise/risk-based combos: status×paymentType, country×state, startDate×endDate (before/equal/after), min×max, role×operation, valid-body×invalid-header and inverse. Full combinatorial for critical fields; pairwise for lower risk.

## 15. File upload (when applicable)

Positive: valid file, min size, max size, valid/space/case-variant filenames, file+metadata, multiple files.
Negative: missing/empty/zero-byte/oversized file, unsupported extension, extension-vs-content mismatch, wrong MIME, renamed executable, corrupted, password-protected, duplicate file/name, special-char/long/no-extension/multi-extension (`doc.pdf.exe`)/path-like (`../../f.txt`) filename, script content, too many files, missing boundary, wrong part name, missing/invalid metadata, interrupted upload.
Post-upload: stored OK, safe stored name, content unchanged, metadata persisted, unauthorized download blocked, deleted file gone, no path leaks, scanning works.

## 16. Idempotency, duplicates & concurrency

Same request twice | same idempotency key | different request + same key | same request + different keys | retry after client/server timeout | concurrent duplicates. Expected: one resource, or existing returned, or 409 — defined.
Concurrency: simultaneous updates, duplicate-unique creation race, update-during-delete, read-during-update, same version / different ETags, high parallel volume → no dup records, no lost updates, no corruption, correct conflict, rollback works.

## 17. Security inputs (strings, headers, path & query params)

SQL-like, HTML, JS, template expressions, command text, path traversal, null byte, CR/LF injection, deep JSON, huge payload, repeated params, mass assignment of restricted fields, internal property names, unexpected properties. Verify: rejected or treated as data, no internal detail leaks, no unauthorized field updates.

## 18. Performance & reliability

Response time (normal/min/max payload, large response, concurrent users, repeated calls), slow dependency, DB timeout, external service down. Reliability: retries, connect/read timeout, circuit breaker, partial failure, restart mid-processing, rollback, queue failure, duplicate events. Rate limiting: 429 + Retry-After.

## 19. DB / persistence validation

Create/update: correct table+record, no duplicates, all fields persisted, defaults, audit fields, timestamps, created/modified-by, commit on success, rollback on failure, child records, referential integrity, soft-delete flag, encryption/masking, API values == DB values.
GET: correct record, filter/sort/pagination match DB, deleted/inactive handled.

## 20. Per-FIELD generation pattern (apply to every request field)

valid | missing | null | empty | whitespace | wrong datatype | min | min-1 | max | max+1 | invalid format | unsupported value | special chars | Unicode | duplicate | business-rule violation | unauthorized value | dependent-field combo.

## 21. Per-ENDPOINT generation pattern

valid request | mandatory-only | all fields | missing mandatory header | invalid auth | unauthorized user | missing body | malformed body | invalid path param | invalid query param | unsupported Content-Type | unsupported HTTP method | not found | duplicate request | business conflict | schema validation | DB validation | response-time | security input | concurrent requests.

## 22. Priority model

- **P0** (every build): happy path, required fields, authN, authZ, critical business rules, response schema, DB persistence, critical file checks, duplicate-transaction protection, no 500s on standard invalid input.
- **P1** (daily regression): boundaries, enums, header variations, invalid datatypes, object-level authZ, nested/array validation, idempotency, error contract.
- **P2** (full regression): Unicode/special chars, unsupported query params, multi-invalid combos, concurrency, large payloads, advanced date/timezone.
- **P3**: rare encodings, extreme limits, infra failures, endurance.

## 23. Test-case template columns

TC ID | Endpoint | Method | Category | Scenario | Preconditions | Path params | Query params | Headers | Body | Expected status | Expected response | Schema validation | DB validation | Security validation | Priority | Automation status | Actual result | Status.
